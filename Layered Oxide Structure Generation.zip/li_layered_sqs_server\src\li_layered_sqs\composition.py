from __future__ import annotations

import math
from decimal import Decimal

from .constants import RESOLUTION_RULES
from .exceptions import CompositionError, ResolutionError
from .models import CompositionPlan, Formula


def _is_multiple(value: Decimal, step: Decimal) -> bool:
    return value % step == 0


def _multinomial_count(counts: list[int]) -> int:
    remaining = sum(counts)
    result = 1
    for count in counts[:-1]:
        result *= math.comb(remaining, count)
        remaining -= count
    return result


def plan_composition(formula: Formula) -> CompositionPlan:
    selected = next((rule for rule in RESOLUTION_RULES if all(_is_multiple(v, rule[0]) for v in formula.tm_fractions.values())), None)
    if selected is None:
        raise ResolutionError("组成需要小于 0.01 的分辨率")
    resolution, supercell, tm_sites = selected
    if resolution == Decimal("0.01"):
        nominal = {symbol: int(fraction * 100) for symbol, fraction in formula.tm_fractions.items()}
        actual = dict(nominal)
        actual["Ni"] -= 1
    else:
        nominal = {symbol: int(fraction * tm_sites) for symbol, fraction in formula.tm_fractions.items()}
        actual = dict(nominal)
    if any(count < 0 for count in actual.values()) or sum(actual.values()) != tm_sites:
        raise CompositionError(f"无法将组成映射到固定 {tm_sites} 个 TM 位: {actual}")
    raw = _multinomial_count(list(actual.values()))
    return CompositionPlan(formula, resolution, supercell, tm_sites, nominal, actual, raw)
