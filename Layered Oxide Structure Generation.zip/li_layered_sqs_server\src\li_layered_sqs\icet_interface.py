from __future__ import annotations

from pathlib import Path

from ase import __version__ as ase_version
from icet import ClusterSpace
from icet import __version__ as icet_version
from icet.tools.structure_generation import _get_sqs_cluster_vector, generate_sqs_from_supercells
from mchammer.calculators import compare_cluster_vectors
from pymatgen.core import Structure
from pymatgen.io.ase import AseAtomsAdaptor
from pymatgen.io.vasp import Poscar

from .models import CompositionPlan, Settings
from .parent import make_supercell, symbol


def build_cluster_space(parent: Structure, plan: CompositionPlan, cutoff: float) -> tuple[ClusterSpace, dict]:
    allowed = list(plan.actual_tm_counts)
    chemical_symbols = [allowed if symbol(site) == "Ni" else [symbol(site)] for site in parent]
    cluster_space = ClusterSpace(
        AseAtomsAdaptor.get_atoms(parent),
        cutoffs=[cutoff],
        chemical_symbols=chemical_symbols,
    )
    sublattices = cluster_space.get_sublattices(cluster_space.primitive_structure)
    active = [item.symbol for item in sublattices if len(item.chemical_symbols) > 1]
    if len(active) != 1:
        raise RuntimeError(f"预期一个 active sublattice，实际为 {active}")
    concentrations = {active[0]: {key: value / plan.tm_sites for key, value in plan.actual_tm_counts.items()}}
    return cluster_space, concentrations


def score_atoms(atoms, cluster_space: ClusterSpace, concentrations: dict, settings: Settings) -> float:
    target = _get_sqs_cluster_vector(cluster_space, concentrations)
    vector = cluster_space.get_cluster_vector(atoms)
    return float(compare_cluster_vectors(
        cv_1=vector,
        cv_2=target,
        as_list=cluster_space.as_list,
        optimality_weight=settings.optimality_weight,
        tol=settings.tolerance,
    ))


def generate_candidate(
    parent_path: str,
    supercell_matrix: tuple[int, int, int],
    actual_counts: dict[str, int],
    nominal_counts: dict[str, int],
    formula: str,
    resolution: str,
    cutoff: float,
    seed: int,
    settings_data: dict,
    output_path: str,
) -> dict:
    settings = Settings(**settings_data)
    parent = Structure.from_file(parent_path)
    from decimal import Decimal

    from .models import Formula
    plan = CompositionPlan(
        Formula(formula, {}, {key: Decimal(value) for key, value in nominal_counts.items()}),
        Decimal(resolution), supercell_matrix, sum(actual_counts.values()), nominal_counts, actual_counts, 0,
    )
    supercell = make_supercell(parent, supercell_matrix)
    cluster_space, concentrations = build_cluster_space(parent, plan, cutoff)
    atoms = generate_sqs_from_supercells(
        cluster_space=cluster_space,
        supercells=[AseAtomsAdaptor.get_atoms(supercell)],
        target_concentrations=concentrations,
        T_start=settings.t_start,
        T_stop=settings.t_stop,
        n_steps=settings.n_steps,
        optimality_weight=settings.optimality_weight,
        random_seed=seed,
        random_start=True,
        tol=settings.tolerance,
    )
    q = score_atoms(atoms, cluster_space, concentrations, settings)
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    Poscar(AseAtomsAdaptor.get_structure(atoms), comment=f"candidate seed={seed}", sort_structure=False).write_file(
        path, significant_figures=16
    )
    return {"seed": seed, "q": q, "path": str(path), "status": "completed"}


def versions() -> dict[str, str]:
    import sys

    import numpy
    import pymatgen.core
    import spglib

    return {
        "Python": sys.version.split()[0], "numpy": numpy.__version__,
        "pymatgen": getattr(pymatgen.core, "__version__", "unknown"),
        "ASE": ase_version, "icet": icet_version, "spglib": spglib.__version__,
    }
