from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation

from pymatgen.core.periodic_table import Element

from .constants import NI_MIN, element_sort_key, tm_sort_key
from .exceptions import CompositionError, ElementError, FormulaParseError, NiContentError
from .models import Formula

_TOKEN = re.compile(r"([A-Z][a-z]?)(?:(\d+(?:\.\d*)?|\.\d+))?")


def _format_decimal(value: Decimal) -> str:
    if value == 1:
        return ""
    text = format(value.normalize(), "f")
    return text.rstrip("0").rstrip(".") if "." in text else text


def parse_formula(text: str) -> Formula:
    if not text or any(character.isspace() for character in text):
        raise FormulaParseError("化学式不能为空或包含空白")
    position = 0
    amounts: dict[str, Decimal] = {}
    while position < len(text):
        match = _TOKEN.match(text, position)
        if match is None:
            raise FormulaParseError(f"化学式在位置 {position + 1} 含非法字符或语法")
        symbol, raw_amount = match.groups()
        if symbol in amounts:
            raise FormulaParseError(f"元素重复: {symbol}")
        if symbol not in {"Li", "O"}:
            try:
                element = Element(symbol)
            except ValueError as exc:
                raise ElementError(f"未知元素: {symbol}") from exc
            if not element.is_metal:
                raise ElementError(f"仅允许金属元素占据 Ni 派生位点: {symbol}")
        try:
            amount = Decimal(raw_amount) if raw_amount is not None else Decimal(1)
        except InvalidOperation as exc:
            raise FormulaParseError(f"无效系数: {raw_amount}") from exc
        if not amount.is_finite() or amount <= 0:
            raise FormulaParseError(f"元素 {symbol} 的系数必须为正有限数")
        amounts[symbol] = amount
        position = match.end()
    if amounts.get("Li") != 1:
        raise CompositionError(f"Li 必须严格为 1，当前为 {amounts.get('Li')}")
    if amounts.get("O") != 2:
        raise CompositionError(f"O 必须严格为 2，当前为 {amounts.get('O')}")
    tm = {symbol: amounts[symbol] for symbol in sorted(amounts.keys() - {"Li", "O"}, key=tm_sort_key)}
    if "Ni" not in tm:
        raise CompositionError("Ni 必须存在")
    tm_sum = sum(tm.values(), Decimal(0))
    if tm_sum != 1:
        raise CompositionError(f"TM nominal fractions 之和必须严格为 1，当前为 {tm_sum}")
    if tm["Ni"] < NI_MIN:
        raise NiContentError(
            f"输入化学式: {text}; Ni fraction: {tm['Ni']}; Requirement: Ni >= {NI_MIN}; "
            "Primary rejection reason: insufficient Ni fraction."
        )
    normalized = "".join(
        symbol + _format_decimal(amounts[symbol]) for symbol in sorted(amounts, key=element_sort_key)
    )
    return Formula(normalized=normalized, amounts=amounts, tm_fractions=tm)
