#!/usr/bin/env bash
#BSUB -J li_sqs
#BSUB -n 32
#BSUB -R "span[hosts=1]"
#BSUB -o li_sqs.%J.out
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"
export OMP_NUM_THREADS=1
exec "$PYTHON_BIN" "$ROOT/portable_runner.py" -i "${SQS_INPUT:-$ROOT/SQSINCAR}" --workers "${LSB_DJOB_NUMPROC:-1}"
