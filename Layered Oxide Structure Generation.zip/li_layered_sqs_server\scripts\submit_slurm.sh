#!/usr/bin/env bash
#SBATCH --job-name=li_sqs
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=32
#SBATCH --output=li_sqs.%j.out
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"
export OMP_NUM_THREADS=1
exec "$PYTHON_BIN" "$ROOT/portable_runner.py" -i "${SQS_INPUT:-$ROOT/SQSINCAR}" --workers "${SLURM_CPUS_PER_TASK}"
