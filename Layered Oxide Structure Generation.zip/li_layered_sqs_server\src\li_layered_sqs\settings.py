from __future__ import annotations

import sys
from dataclasses import replace
from pathlib import Path

import yaml

from .models import Settings

QUALITY_PROFILES = {
    "standard": {"n_steps": 60000, "oversample_factor": 8, "min_unique_pool": 20, "batch_size": 32, "max_sqs_runs": 500},
    "high": {"n_steps": 200000, "oversample_factor": 20, "min_unique_pool": 50, "batch_size": 64, "max_sqs_runs": 2000},
    "ultra": {"n_steps": 500000, "oversample_factor": 30, "min_unique_pool": 100, "batch_size": 64, "max_sqs_runs": 5000},
}


def project_root() -> Path:
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "pyproject.toml").is_file() and (parent / "resources" / "POSCAR_LiNiO2").is_file():
            return parent
    installed = Path(sys.prefix) / "share" / "li_layered_sqs"
    if (installed / "resources" / "POSCAR_LiNiO2").is_file():
        return installed
    raise FileNotFoundError("无法定位 canonical resources/POSCAR_LiNiO2")


def load_settings(path: Path | None = None, quality: str = "high") -> Settings:
    if quality not in QUALITY_PROFILES:
        raise ValueError(f"未知质量档位: {quality}")
    config_path = path or project_root() / "config" / "defaults.yaml"
    data = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    sqs = data["sqs"]
    search = data["search"]
    profile = QUALITY_PROFILES[quality]
    return Settings(
        exact_enumeration_limit=int(search["exact_enumeration_limit"]),
        quality=quality,
        oversample_factor=profile["oversample_factor"],
        min_unique_pool=profile["min_unique_pool"],
        batch_size=profile["batch_size"],
        max_sqs_runs=profile["max_sqs_runs"],
        n_steps=profile["n_steps"],
        t_start=float(sqs["T_start"]),
        t_stop=float(sqs["T_stop"]),
        optimality_weight=float(sqs["optimality_weight"]),
        tolerance=float(sqs["tolerance"]),
    )


def with_n_steps(settings: Settings, n_steps: int) -> Settings:
    return replace(settings, n_steps=n_steps)
