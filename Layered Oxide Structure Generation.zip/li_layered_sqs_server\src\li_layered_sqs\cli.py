from __future__ import annotations

import argparse
import json
import logging
import sys

from .exceptions import LiSqsError
from .pipeline import default_workers, dry_run, run
from .settings import load_settings


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="li-sqs", description="Layered high-Ni fixed-supercell SQS generator")
    parser.add_argument("-i", "--input", default="SQSINCAR", help="SQSINCAR 路径")
    parser.add_argument("--workers", type=int, default=default_workers(), help="单节点 worker 进程数")
    parser.add_argument("--resume", action="store_true", help="从兼容 checkpoint 续跑")
    parser.add_argument("--overwrite", action="store_true", help="重建已存在的公式输出目录")
    parser.add_argument("--dry-run", action="store_true", help="仅验证并规划，不运行候选搜索")
    parser.add_argument("--seed", type=int, help="确定性 base seed；多公式会使用稳定索引偏移")
    parser.add_argument("--quality", choices=("standard", "high", "ultra"), default="high", help="搜索质量/成本档位")
    parser.add_argument("--log-level", choices=("DEBUG", "INFO", "WARNING", "ERROR"), default="INFO")
    parser.add_argument("--n-steps", type=int, help="覆盖每个 Monte Carlo run 的步数（测试用途）")
    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.workers < 1:
        parser.error("--workers 必须 >= 1")
    if args.seed is not None and not 0 <= args.seed < 2_147_483_647:
        parser.error("--seed 必须在 0..2147483646 范围内")
    if args.resume and args.overwrite:
        parser.error("--resume 与 --overwrite 不能同时使用")
    logging.basicConfig(level=getattr(logging, args.log_level), format="%(asctime)s | %(levelname)s | %(message)s")
    try:
        settings = load_settings(quality=args.quality)
        if args.n_steps is not None:
            if args.n_steps < 1:
                parser.error("--n-steps 必须 >= 1")
            from dataclasses import replace
            settings = replace(settings, n_steps=args.n_steps)
        result = dry_run(args.input, settings, args.workers, args.seed) if args.dry_run else run(
            args.input, settings, args.workers, args.resume, args.overwrite, args.seed
        )
        print(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False))
    except LiSqsError as exc:
        print(f"[{type(exc).__name__}] {exc}", file=sys.stderr)
        raise SystemExit(2) from exc
    except KeyboardInterrupt as exc:
        print("运行已中断；已尽力保存 checkpoint。", file=sys.stderr)
        raise SystemExit(130) from exc


if __name__ == "__main__":
    main()
