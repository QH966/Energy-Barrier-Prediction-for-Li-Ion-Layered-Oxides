"""Layered high-Ni fixed-supercell SQS generator."""

__version__ = "1.0.0"
