from __future__ import annotations

import json
import os
from pathlib import Path

from .exceptions import ResumeStateError


def atomic_write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    os.replace(temporary, path)


def load_state(path: Path, parameter_hash: str) -> dict:
    if not path.is_file():
        raise ResumeStateError(f"不存在可续跑的 checkpoint: {path}")
    state = json.loads(path.read_text(encoding="utf-8"))
    if state.get("parameter_hash") != parameter_hash:
        raise ResumeStateError("checkpoint 与当前输入、母相或科学/工程参数不兼容")
    return state
