class LiSqsError(Exception):
    """Base error for expected user-facing failures."""


class InputFileError(LiSqsError):
    pass


class FormulaParseError(LiSqsError):
    pass


class ElementError(LiSqsError):
    pass


class CompositionError(LiSqsError):
    pass


class NiContentError(LiSqsError):
    pass


class ResolutionError(LiSqsError):
    pass


class ParentStructureError(LiSqsError):
    pass


class NeighborShellError(LiSqsError):
    pass


class SQSGenerationError(LiSqsError):
    pass


class DeduplicationError(LiSqsError):
    pass


class OutputValidationError(LiSqsError):
    pass


class ResumeStateError(LiSqsError):
    pass
