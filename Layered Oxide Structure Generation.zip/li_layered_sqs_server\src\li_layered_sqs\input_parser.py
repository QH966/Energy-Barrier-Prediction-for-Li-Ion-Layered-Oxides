from __future__ import annotations

from pathlib import Path

from .exceptions import InputFileError
from .formula_parser import parse_formula
from .models import InputSpec

_ALLOWED_KEYS = {"FORMULA", "N_STRUCTURES"}


def parse_sqsincar(path: str | Path) -> InputSpec:
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise InputFileError(f"输入文件不存在: {source}")
    text = source.read_text(encoding="utf-8")
    formula_texts: list[str] = []
    n_structures_text: str | None = None
    for line_number, raw in enumerate(text.splitlines(), start=1):
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if "=" not in line:
            raise InputFileError(f"第 {line_number} 行缺少 '=': {raw.strip()}")
        key, value = (part.strip() for part in line.split("=", 1))
        key = key.upper()
        if key not in _ALLOWED_KEYS:
            raise InputFileError(f"第 {line_number} 行存在未知 key: {key}")
        if not value:
            raise InputFileError(f"第 {line_number} 行 {key} 的值为空")
        if key == "FORMULA":
            # 逗号只在赋值层级分隔公式，不传入化学式解析器，避免改变其语法。
            items = [item.strip() for item in value.split(",")]
            if any(not item for item in items):
                raise InputFileError(f"第 {line_number} 行 FORMULA 含空的逗号分隔项")
            formula_texts.extend(items)
        elif n_structures_text is not None:
            raise InputFileError(f"第 {line_number} 行重复 key: N_STRUCTURES")
        else:
            n_structures_text = value
    missing = []
    if not formula_texts:
        missing.append("FORMULA")
    if n_structures_text is None:
        missing.append("N_STRUCTURES")
    if missing:
        raise InputFileError(f"缺少必填 key: {', '.join(missing)}")
    try:
        n_structures = int(n_structures_text)
    except ValueError as exc:
        raise InputFileError("N_STRUCTURES 必须是整数") from exc
    if str(n_structures) != n_structures_text and n_structures_text not in {f"+{n_structures}"}:
        raise InputFileError("N_STRUCTURES 必须是十进制整数")
    if not 1 <= n_structures <= 1000:
        raise InputFileError("N_STRUCTURES 必须在 1..1000 范围内")

    normalized_seen: dict[str, str] = {}
    snapshots: list[str] = []
    for formula_text in formula_texts:
        normalized = parse_formula(formula_text).normalized
        if normalized in normalized_seen:
            raise InputFileError(
                f"重复化学式（规范化后相同）: {formula_text} 与 {normalized_seen[normalized]} -> {normalized}"
            )
        normalized_seen[normalized] = formula_text
        snapshots.append(
            f"# Layered LiNiO2 SQS generator\nFORMULA = {formula_text}\nN_STRUCTURES = {n_structures}\n"
        )
    return InputSpec(tuple(formula_texts), n_structures, source, tuple(snapshots))
