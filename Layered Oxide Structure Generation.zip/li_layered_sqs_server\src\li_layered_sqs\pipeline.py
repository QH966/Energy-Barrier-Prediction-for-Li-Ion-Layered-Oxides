from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from .checkpoint import atomic_write_json, load_state
from .composition import plan_composition
from .deduplication import deduplicate, symmetry_permutations
from .enumeration import enumerate_candidates
from .exceptions import InputFileError, LiSqsError, SQSGenerationError
from .formula_parser import parse_formula
from .icet_interface import generate_candidate, versions
from .input_parser import parse_sqsincar
from .models import InputSpec, Settings
from .output import write_outputs
from .parent import load_parent, make_supercell, neighbor_shells, sha256_file
from .settings import project_root

LOGGER = logging.getLogger("li_layered_sqs")
_SEED_OFFSET = 1_000_003
_SEED_MODULUS = 2_147_483_647


def default_workers() -> int:
    allocation = os.environ.get("SLURM_CPUS_PER_TASK")
    if allocation and allocation.isdigit():
        return max(1, int(allocation))
    return max(1, (os.cpu_count() or 2) - 1)


def deterministic_seed(formula: str, requested: int) -> int:
    digest = hashlib.sha256(f"{formula}|{requested}|1.0.0".encode()).digest()
    return int.from_bytes(digest[:4], "big") & 0x7FFFFFFF


def formula_seed(base_seed: int | None, formula_index: int, normalized_formula: str, requested: int) -> int:
    if base_seed is None:
        return deterministic_seed(normalized_formula, requested)
    return (base_seed + formula_index * _SEED_OFFSET) % _SEED_MODULUS


def target_unique_pool(requested: int, settings: Settings) -> int:
    return min(settings.max_sqs_runs, max(requested * settings.oversample_factor, settings.min_unique_pool))


def parameter_hash(payload: dict) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def prepare_formula(formula_text: str):
    formula = parse_formula(formula_text)
    plan = plan_composition(formula)
    root = project_root()
    parent_path = root / "resources" / "POSCAR_LiNiO2"
    parent = load_parent(parent_path)
    shells = neighbor_shells(parent)
    cutoff = (shells[2] + shells[3]) / 2.0
    supercell = make_supercell(parent, plan.supercell)
    return plan, parent_path, parent, shells, cutoff, supercell


def _single_formula_spec(input_spec: InputSpec, index: int) -> InputSpec:
    return InputSpec(
        (input_spec.formula_texts[index],),
        input_spec.n_structures,
        input_spec.source,
        (input_spec.snapshots[index],),
    )


def _dry_run_job(
    formula_text: str,
    requested: int,
    settings: Settings,
    workers: int,
    seed: int,
    formula_index: int,
) -> dict:
    plan, parent_path, parent, shells, cutoff, _ = prepare_formula(formula_text)
    mode = "exact_enumeration" if plan.raw_configuration_count <= settings.exact_enumeration_limit else "parallel_fixed_supercell_monte_carlo"
    if len(plan.actual_tm_counts) > 1:
        from .icet_interface import build_cluster_space

        cluster_space, _ = build_cluster_space(parent, plan, cutoff)
        cluster_space_length = len(cluster_space)
    else:
        cluster_space_length = 1
    return {
        "formula_index": formula_index,
        "formula": plan.formula.normalized,
        "requested_structures": requested,
        "seed": seed,
        "quality": settings.quality,
        "n_steps": settings.n_steps,
        "target_unique_pool": target_unique_pool(requested, settings),
        "max_sqs_runs": settings.max_sqs_runs,
        "oversample_factor": settings.oversample_factor,
        "batch_size": settings.batch_size,
        "ni_fraction": str(plan.formula.tm_fractions["Ni"]),
        "resolution": str(plan.resolution),
        "supercell": list(plan.supercell),
        "tm_sites": plan.tm_sites,
        "nominal_tm_counts": plan.nominal_tm_counts,
        "actual_tm_counts": plan.actual_tm_counts,
        "raw_configuration_count": plan.raw_configuration_count,
        "search_mode": mode,
        "workers": workers,
        "parent_path": str(parent_path),
        "neighbor_shells_angstrom": shells[:4],
        "pair_cutoff_angstrom": cutoff,
        "cluster_space_length": cluster_space_length,
        "output": plan.formula.normalized,
    }


def dry_run(
    input_path: str | Path,
    settings: Settings,
    workers: int,
    base_seed: int | None = None,
) -> dict:
    input_spec = parse_sqsincar(input_path)
    jobs = []
    for index, formula_text in enumerate(input_spec.formula_texts):
        normalized = parse_formula(formula_text).normalized
        seed = formula_seed(base_seed, index, normalized, input_spec.n_structures)
        jobs.append(_dry_run_job(formula_text, input_spec.n_structures, settings, workers, seed, index))
    return {
        "status": "DRY_RUN",
        "formula_count": len(jobs),
        "requested_structures_per_formula": input_spec.n_structures,
        "quality": settings.quality,
        "jobs": jobs,
    }


def run(
    input_path: str | Path,
    settings: Settings,
    workers: int,
    resume: bool,
    overwrite: bool,
    base_seed: int | None,
) -> dict:
    started = time.time()
    input_spec = parse_sqsincar(input_path)
    summaries = []
    for index, formula_text in enumerate(input_spec.formula_texts):
        normalized = parse_formula(formula_text).normalized
        seed = formula_seed(base_seed, index, normalized, input_spec.n_structures)
        try:
            summary = _run_formula(
                _single_formula_spec(input_spec, index),
                settings,
                workers,
                resume,
                overwrite,
                seed,
                index,
            )
        except LiSqsError as exc:
            raise type(exc)(f"公式 {index + 1}/{len(input_spec.formula_texts)} ({normalized}) 失败: {exc}") from exc
        except Exception as exc:
            raise SQSGenerationError(
                f"公式 {index + 1}/{len(input_spec.formula_texts)} ({normalized}) 失败: {exc}"
            ) from exc
        summaries.append({"formula_index": index, "formula": normalized, "seed": seed, **summary})
    overall_status = "PARTIAL" if any(item["status"] == "PARTIAL" for item in summaries) else "SUCCESS"
    return {
        "status": overall_status,
        "formula_count": len(summaries),
        "quality": settings.quality,
        "runtime_seconds": time.time() - started,
        "summaries": summaries,
    }


def _run_formula(
    input_spec: InputSpec,
    settings: Settings,
    workers: int,
    resume: bool,
    overwrite: bool,
    seed: int,
    formula_index: int,
) -> dict:
    started = time.time()
    plan, parent_path, parent, shells, cutoff, supercell = prepare_formula(input_spec.formula_texts[0])
    output_root = Path.cwd() / plan.formula.normalized
    state_path = output_root / ".work" / "state.json"
    cache = output_root / ".work" / "candidates"
    if output_root.exists() and not resume and not overwrite:
        raise InputFileError(f"输出目录已存在，拒绝静默覆盖: {output_root}；请使用 --resume 或 --overwrite")
    resume_existing = resume and output_root.exists()
    if overwrite and output_root.exists():
        protected = (Path.cwd() / ".workbuddy").resolve()
        target = output_root.resolve()
        if target == protected or protected in target.parents:
            raise InputFileError("拒绝覆盖 .workbuddy 目录")
        shutil.rmtree(output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    cache.mkdir(parents=True, exist_ok=True)
    parent_hash = sha256_file(parent_path)
    search_mode = "exact_enumeration" if plan.raw_configuration_count <= settings.exact_enumeration_limit else "parallel_fixed_supercell_monte_carlo"
    pool_target = target_unique_pool(input_spec.n_structures, settings)
    params = {
        "formula": plan.formula.normalized,
        "formula_index": formula_index,
        "requested": input_spec.n_structures,
        "resolution": str(plan.resolution),
        "supercell": plan.supercell,
        "actual_counts": plan.actual_tm_counts,
        "parent_sha256": parent_hash,
        "settings": asdict(settings),
        "target_unique_pool": pool_target,
        "base_seed": seed,
        "search_mode": search_mode,
    }
    digest = parameter_hash(params)
    state = load_state(state_path, digest) if resume_existing else {
        "parameter_hash": digest,
        "parameters": params,
        "status": "running",
        "completed": [],
    }
    atomic_write_json(state_path, state)
    timestamp = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    log_lines = [
        f"{timestamp} | Run started: formula={plan.formula.normalized}; requested={input_spec.n_structures}",
        f"Parent SHA256={parent_hash}",
        f"Ni-Ni shells (A): {', '.join(f'{item:.8f}' for item in shells[:4])}",
        f"Pair cutoff between 3NN and 4NN: {cutoff:.8f} A",
        f"Fixed supercell={plan.supercell}; TM sites={plan.tm_sites}",
        f"Nominal TM counts={plan.nominal_tm_counts}; actual TM counts={plan.actual_tm_counts}",
        f"raw_configuration_count={plan.raw_configuration_count}; search_mode={search_mode}; workers={workers}; base_seed={seed}",
        f"quality={settings.quality}; n_steps={settings.n_steps}; target_unique_pool={pool_target}; max_sqs_runs={settings.max_sqs_runs}",
    ]
    permutations = symmetry_permutations(supercell)
    completed = list(state.get("completed", []))
    try:
        if search_mode == "exact_enumeration":
            if not completed:
                completed = enumerate_candidates(parent, plan, cutoff, settings, cache, permutations)
                state["completed"] = completed
                atomic_write_json(state_path, state)
            log_lines.append(f"Exhaustive raw occupations completed: {plan.raw_configuration_count}")
        else:
            used_seeds = {int(item["seed"]) for item in completed}
            seeds = [
                (seed + index) % _SEED_MODULUS
                for index in range(settings.max_sqs_runs)
                if (seed + index) % _SEED_MODULUS not in used_seeds
            ]
            unique_now, _, _ = deduplicate(completed, supercell, permutations) if completed else ([], 0, 0)
            while len(unique_now) < pool_target and len(completed) < settings.max_sqs_runs and seeds:
                batch_size = min(settings.batch_size, settings.max_sqs_runs - len(completed), len(seeds))
                batch = seeds[:batch_size]
                seeds = seeds[batch_size:]
                settings_data = asdict(settings)
                with ProcessPoolExecutor(max_workers=workers) as executor:
                    futures = {
                        executor.submit(
                            generate_candidate,
                            str(parent_path),
                            plan.supercell,
                            plan.actual_tm_counts,
                            plan.nominal_tm_counts,
                            plan.formula.normalized,
                            str(plan.resolution),
                            cutoff,
                            candidate_seed,
                            settings_data,
                            str(cache / f"seed_{candidate_seed}.vasp"),
                        ): candidate_seed
                        for candidate_seed in batch
                    }
                    for future in as_completed(futures):
                        completed.append(future.result())
                        completed.sort(key=lambda item: item["seed"])
                        state["completed"] = completed
                        state["last_completed_seed"] = futures[future]
                        atomic_write_json(state_path, state)
                unique_now, _, _ = deduplicate(completed, supercell, permutations)
                log_lines.append(
                    f"Batch complete: runs={len(completed)}; unique={len(unique_now)}; "
                    f"best_Q={min(item['q'] for item in unique_now):.12g}"
                )
        unique, exact_duplicates, symmetry_duplicates = deduplicate(completed, supercell, permutations)
        selected = unique[: input_spec.n_structures]
        state["status"] = "completed"
        state["unique_count"] = len(unique)
        atomic_write_json(state_path, state)
        stats = {
            "raw_candidates": len(completed),
            "exact_duplicates": exact_duplicates,
            "symmetry_duplicates": symmetry_duplicates,
            "unique_count": len(unique),
            "symmetry_permutations": len(permutations),
            "workers": workers,
            "parameters": params,
        }
        log_lines.append(
            f"Dedup: raw={len(completed)}; exact_removed={exact_duplicates}; "
            f"symmetry_removed={symmetry_duplicates}; unique={len(unique)}"
        )
        log_lines.append(f"Requested structures: {input_spec.n_structures}; Structures written: {len(selected)}")
        return write_outputs(
            output_root,
            selected,
            input_spec,
            plan,
            parent_path,
            parent_hash,
            supercell,
            shells,
            cutoff,
            settings,
            search_mode,
            stats,
            versions(),
            started,
            log_lines,
        )
    except BaseException:
        state["status"] = "interrupted_or_failed"
        state["completed"] = completed
        atomic_write_json(state_path, state)
        raise
