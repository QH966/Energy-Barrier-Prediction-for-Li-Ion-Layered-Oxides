from __future__ import annotations

import hashlib

import numpy as np
import spglib
from pymatgen.core import Structure

from .parent import map_to_reference, symbol


def occupation_tuple(structure: Structure, supercell: Structure) -> tuple[str, ...]:
    reference = [site.frac_coords for site in supercell if symbol(site) == "Ni"]
    active = [site for site in structure if symbol(site) not in {"Li", "O"}]
    mapping = map_to_reference(reference, [site.frac_coords for site in active])
    return tuple(symbol(active[index]) for index in mapping)


def occupation_hash(occupation: tuple[str, ...]) -> str:
    return hashlib.sha256("|".join(occupation).encode("utf-8")).hexdigest()


def symmetry_permutations(supercell: Structure) -> list[tuple[int, ...]]:
    lattice = np.asarray(supercell.lattice.matrix)
    positions = np.asarray([site.frac_coords % 1.0 for site in supercell])
    numbers = np.asarray([{"Li": 3, "Ni": 28, "O": 8}[symbol(site)] for site in supercell])
    symmetry = spglib.get_symmetry((lattice, positions, numbers), symprec=1.0e-5)
    if symmetry is None:
        raise RuntimeError("spglib 无法识别父超胞空间群")
    active = [site.frac_coords % 1.0 for site in supercell if symbol(site) == "Ni"]
    permutations = set()
    for rotation, translation in zip(symmetry["rotations"], symmetry["translations"], strict=True):
        transformed = [(np.dot(rotation, coord) + translation) % 1.0 for coord in active]
        permutations.add(tuple(map_to_reference(active, transformed, tolerance=2.0e-5)))
    return sorted(permutations)


def symmetry_canonical_key(occupation: tuple[str, ...], permutations: list[tuple[int, ...]]) -> str:
    if not permutations:
        raise ValueError("空间群 permutation 列表不能为空")
    keys = []
    for permutation in permutations:
        transformed = [""] * len(occupation)
        for source, target in enumerate(permutation):
            transformed[target] = occupation[source]
        keys.append("|".join(transformed))
    return hashlib.sha256(min(keys).encode("utf-8")).hexdigest()


def deduplicate(candidates: list[dict], supercell: Structure, permutations: list[tuple[int, ...]]) -> tuple[list[dict], int, int]:
    exact_seen: set[str] = set()
    symmetry_seen: set[str] = set()
    unique: list[dict] = []
    exact_duplicates = symmetry_duplicates = 0
    for candidate in sorted(candidates, key=lambda item: (item["q"], item["seed"])):
        structure = Structure.from_file(candidate["path"])
        occupation = occupation_tuple(structure, supercell)
        exact = occupation_hash(occupation)
        if exact in exact_seen:
            exact_duplicates += 1
            continue
        exact_seen.add(exact)
        canonical = symmetry_canonical_key(occupation, permutations)
        if canonical in symmetry_seen:
            symmetry_duplicates += 1
            continue
        symmetry_seen.add(canonical)
        unique.append({**candidate, "structure": structure, "occupation_hash": exact, "symmetry_canonical_key": canonical})
    return unique, exact_duplicates, symmetry_duplicates
