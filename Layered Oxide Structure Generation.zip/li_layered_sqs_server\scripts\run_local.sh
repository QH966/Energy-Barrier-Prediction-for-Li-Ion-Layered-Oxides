#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
WORKERS="${WORKERS:-$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf '1')}"
exec "$PYTHON_BIN" "$ROOT/portable_runner.py" -i "${1:-$ROOT/SQSINCAR}" --workers "$WORKERS"
