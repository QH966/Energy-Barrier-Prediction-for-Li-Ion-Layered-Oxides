from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

from pymatgen.io.ase import AseAtomsAdaptor
from pymatgen.io.vasp import Poscar

from .deduplication import symmetry_canonical_key
from .icet_interface import build_cluster_space, score_atoms
from .models import CompositionPlan, Settings
from .parent import make_supercell, symbol


def multiset_occupations(counts: dict[str, int]) -> Iterator[tuple[str, ...]]:
    symbols = tuple(counts)
    remaining = dict(counts)
    total = sum(remaining.values())
    current: list[str] = []

    def visit() -> Iterator[tuple[str, ...]]:
        if len(current) == total:
            yield tuple(current)
            return
        for item in symbols:
            if remaining[item]:
                remaining[item] -= 1
                current.append(item)
                yield from visit()
                current.pop()
                remaining[item] += 1

    yield from visit()


def enumerate_candidates(parent, plan: CompositionPlan, cutoff: float, settings: Settings, cache: Path, permutations) -> list[dict]:
    supercell = make_supercell(parent, plan.supercell)
    active_indices = [index for index, site in enumerate(supercell) if symbol(site) == "Ni"]
    seen: set[str] = set()
    candidates: list[dict] = []
    cache.mkdir(parents=True, exist_ok=True)
    if len(plan.actual_tm_counts) == 1:
        path = cache / "enumerated_00000000.vasp"
        Poscar(supercell, comment="unique pure-Ni occupation", sort_structure=False).write_file(path, significant_figures=16)
        return [{"seed": -1, "q": 0.0, "path": str(path), "status": "completed"}]
    cluster_space, concentrations = build_cluster_space(parent, plan, cutoff)
    for index, occupation in enumerate(multiset_occupations(plan.actual_tm_counts)):
        canonical = symmetry_canonical_key(occupation, permutations)
        if canonical in seen:
            continue
        seen.add(canonical)
        structure = supercell.copy()
        for site_index, species in zip(active_indices, occupation, strict=True):
            structure.replace(site_index, species)
        q = score_atoms(AseAtomsAdaptor.get_atoms(structure), cluster_space, concentrations, settings)
        path = cache / f"enumerated_{len(candidates):08d}.vasp"
        Poscar(structure, comment=f"enumerated occupation {index}", sort_structure=False).write_file(path, significant_figures=16)
        candidates.append({"seed": -1 - index, "q": q, "path": str(path), "status": "completed"})
    return candidates
