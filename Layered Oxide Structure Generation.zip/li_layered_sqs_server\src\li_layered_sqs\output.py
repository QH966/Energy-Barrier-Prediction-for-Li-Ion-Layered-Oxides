from __future__ import annotations

import csv
import json
import os
import platform
import socket
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.vasp import Poscar

from .constants import element_sort_key
from .exceptions import OutputValidationError
from .models import CompositionPlan, InputSpec, Settings
from .parent import atom_counts, map_to_reference, sha256_file, symbol


def group_structure(structure: Structure) -> Structure:
    records = sorted(((symbol(site), site.frac_coords.copy()) for site in structure), key=lambda item: element_sort_key(item[0]))
    return Structure(structure.lattice, [item[1] for item in records], [item[2] for item in records], coords_are_cartesian=False, to_unit_cell=True)


def validate_candidate(candidate: Structure, supercell: Structure, plan: CompositionPlan, written_path: Path) -> None:
    expected = {"Li": plan.tm_sites, **plan.actual_tm_counts, "O": 2 * plan.tm_sites}
    if atom_counts(candidate) != expected:
        raise OutputValidationError(f"组成不匹配: {atom_counts(candidate)} != {expected}")
    if len(candidate) != 4 * plan.tm_sites:
        raise OutputValidationError("总原子数不匹配")
    if not np.allclose(candidate.lattice.matrix, supercell.lattice.matrix, atol=1.0e-8):
        raise OutputValidationError("晶格偏离固定超胞")
    for fixed_symbol in ("Li", "O"):
        reference_fixed = [site.frac_coords for site in supercell if symbol(site) == fixed_symbol]
        candidate_fixed = [site.frac_coords for site in candidate if symbol(site) == fixed_symbol]
        map_to_reference(reference_fixed, candidate_fixed, tolerance=1.0e-7)
    reference_active = [site.frac_coords for site in supercell if symbol(site) == "Ni"]
    candidate_active = [site.frac_coords for site in candidate if symbol(site) not in {"Li", "O"}]
    map_to_reference(reference_active, candidate_active, tolerance=1.0e-7)
    round_trip = Structure.from_file(written_path)
    if atom_counts(round_trip) != expected or not np.allclose(round_trip.lattice.matrix, candidate.lattice.matrix, atol=1.0e-8):
        raise OutputValidationError("POSCAR round-trip 验证失败")


def atomic_text(path: Path, content: str) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(content, encoding="utf-8")
    os.replace(temporary, path)


def write_outputs(
    output_root: Path,
    selected: list[dict],
    input_spec: InputSpec,
    plan: CompositionPlan,
    parent_path: Path,
    parent_hash: str,
    supercell: Structure,
    shells: list[float],
    cutoff: float,
    settings: Settings,
    search_mode: str,
    stats: dict,
    versions: dict,
    started: float,
    log_lines: list[str],
) -> dict:
    output_root.mkdir(parents=True, exist_ok=True)
    tm_species = tuple(plan.actual_tm_counts)
    ranking: list[dict] = []
    for rank, item in enumerate(selected, start=1):
        rank_dir = output_root / str(rank)
        rank_dir.mkdir(parents=True, exist_ok=True)
        structure = group_structure(item["structure"])
        actual_text = " ".join(f"{key}{value}" for key, value in {"Li": plan.tm_sites, **plan.actual_tm_counts, "O": 2 * plan.tm_sites}.items())
        poscar = rank_dir / "POSCAR"
        Poscar(structure, comment=f"{plan.formula.normalized} | rank={rank} | actual={actual_text}", sort_structure=False).write_file(poscar, significant_figures=16)
        validate_candidate(structure, supercell, plan, poscar)
        metadata = {
            "formula_nominal": plan.formula.normalized, "rank": rank,
            "requested_structures": input_spec.n_structures, "composition_resolution": str(plan.resolution),
            "supercell": list(plan.supercell), "tm_sites": plan.tm_sites,
            "nominal_composition": {key: str(value) for key, value in plan.formula.tm_fractions.items()},
            "nominal_tm_counts": plan.nominal_tm_counts, "actual_tm_counts": plan.actual_tm_counts,
            "actual_tm_fractions": {key: value / plan.tm_sites for key, value in plan.actual_tm_counts.items()},
            "all_atom_counts": atom_counts(structure),
            "sqs": {"method": "icet generate_sqs_from_supercells" if search_mode != "exact_enumeration" else "exact fixed-cell occupation enumeration with icet scoring",
                    "search_mode": search_mode, "quality": settings.quality,
                    "target_unique_pool": stats["parameters"]["target_unique_pool"],
                    "pair_shells": 3, "pair_shell_distances_angstrom": shells[:3],
                    "fourth_shell_distance_angstrom": shells[3], "pair_cutoff_angstrom": cutoff, "triplets": False,
                    "objective_Q": item["q"], "random_seed": None if item["seed"] < 0 else item["seed"],
                    "n_steps": settings.n_steps if item["seed"] >= 0 else 0, "T_start": settings.t_start,
                    "T_stop": settings.t_stop, "optimality_weight": settings.optimality_weight, "tolerance": settings.tolerance},
            "dedup": {"occupation_hash": item["occupation_hash"], "symmetry_canonical_key": item["symmetry_canonical_key"],
                      "parent_symmetry_permutations_tested": stats["symmetry_permutations"]},
            "parent_structure": {"path": str(parent_path), "sha256": parent_hash},
            "output": {"poscar_sha256": sha256_file(poscar)}, "software": versions,
            "scientific_note": "SQS Q measures cluster-correlation matching, not VASP energy or thermodynamic stability.",
        }
        atomic_text(rank_dir / "metadata.json", json.dumps(metadata, indent=2, ensure_ascii=False, allow_nan=False))
        ranking.append({
            "rank": rank, "formula_nominal": plan.formula.normalized, "resolution": str(plan.resolution),
            "supercell": "x".join(map(str, plan.supercell)), "tm_sites": plan.tm_sites,
            **{f"{item_name}_count": plan.actual_tm_counts.get(item_name, 0) for item_name in tm_species},
            "sqs_Q": item["q"], "random_seed": "" if item["seed"] < 0 else item["seed"], "search_mode": search_mode,
            "poscar_path": f"{rank}/POSCAR", "metadata_path": f"{rank}/metadata.json",
        })
    fields = ["rank", "formula_nominal", "resolution", "supercell", "tm_sites", *[f"{item}_count" for item in tm_species],
              "sqs_Q", "random_seed", "search_mode", "poscar_path", "metadata_path"]
    csv_tmp = output_root / "ranking.csv.tmp"
    with csv_tmp.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(ranking)
    os.replace(csv_tmp, output_root / "ranking.csv")
    atomic_text(output_root / "SQSINCAR.snapshot", input_spec.snapshots[0])
    actual = len(selected)
    partial = actual < input_spec.n_structures
    insufficient = None
    if partial:
        insufficient = ("full fixed-cell occupation space exhausted after symmetry deduplication" if search_mode == "exact_enumeration"
                        else "stochastic search budget exhausted before enough unique structures were obtained")
    summary = {
        "requested_count": input_spec.n_structures, "actual_output_count": actual,
        "status": "PARTIAL" if partial else "SUCCESS", "insufficient_reason": insufficient,
        "search_mode": search_mode, "total_candidates": stats["raw_candidates"],
        "exact_duplicates_removed": stats["exact_duplicates"], "symmetry_duplicates_removed": stats["symmetry_duplicates"],
        "unique_count": stats["unique_count"], "runtime_seconds": time.time() - started,
        "ended_at": datetime.now(timezone.utc).astimezone().isoformat(), "hostname": socket.gethostname(),
        "platform": platform.platform(), "workers": stats["workers"], "parameters": stats["parameters"],
        "versions": versions, "output_dirs": [str(index) for index in range(1, actual + 1)],
        "best_Q": selected[0]["q"] if selected else None, "worst_kept_Q": selected[-1]["q"] if selected else None,
        "warning": "Monte Carlo search is not exhaustive and does not prove global optimality." if search_mode != "exact_enumeration" else None,
    }
    atomic_text(output_root / "run_summary.json", json.dumps(summary, indent=2, ensure_ascii=False, allow_nan=False))
    if partial:
        log_lines.append(f"Reason: {insufficient}.")
    if search_mode != "exact_enumeration":
        log_lines.append("Important: the full combinatorial configuration space was NOT exhaustively enumerated.")
    log_lines.append("SQS Q is not a VASP energy ranking.")
    atomic_text(output_root / "generation.log", "\n".join(log_lines) + "\n")
    return summary
