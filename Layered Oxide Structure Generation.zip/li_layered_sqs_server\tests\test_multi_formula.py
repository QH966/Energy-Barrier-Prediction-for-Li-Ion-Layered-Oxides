from __future__ import annotations

from decimal import Decimal
from pathlib import Path

import pytest

from li_layered_sqs.composition import plan_composition
from li_layered_sqs.exceptions import ElementError, InputFileError, NiContentError
from li_layered_sqs.formula_parser import parse_formula
from li_layered_sqs.input_parser import parse_sqsincar
from li_layered_sqs.pipeline import dry_run
from li_layered_sqs.settings import QUALITY_PROFILES, load_settings

FORMULA_001 = "LiNi0.83Mn0.13Mg0.01Ca0.01Ti0.01Zr0.01O2"
FORMULA_010 = "LiNi0.8Mn0.1Co0.1O2"


def write_input(tmp_path: Path, text: str) -> Path:
    path = tmp_path / "SQSINCAR"
    path.write_text(text, encoding="utf-8")
    return path


def test_repeated_formula_lines_and_snapshots(tmp_path: Path) -> None:
    spec = parse_sqsincar(write_input(
        tmp_path,
        f"FORMULA = {FORMULA_001}\nFORMULA = {FORMULA_010}\nN_STRUCTURES = 5\n",
    ))

    assert spec.formula_texts == (FORMULA_001, FORMULA_010)
    assert spec.n_structures == 5
    assert len(spec.snapshots) == 2
    assert FORMULA_001 in spec.snapshots[0] and FORMULA_010 not in spec.snapshots[0]
    assert FORMULA_010 in spec.snapshots[1] and FORMULA_001 not in spec.snapshots[1]


def test_comma_separated_formulas(tmp_path: Path) -> None:
    spec = parse_sqsincar(write_input(
        tmp_path,
        f"FORMULA = {FORMULA_001}, {FORMULA_010}\nN_STRUCTURES = 2\n",
    ))

    assert spec.formula_texts == (FORMULA_001, FORMULA_010)


def test_rejects_duplicate_normalized_formula(tmp_path: Path) -> None:
    path = write_input(
        tmp_path,
        "FORMULA = LiNi0.8Mn0.1Co0.1O2\n"
        "FORMULA = O2Co0.10Mn0.10Ni0.80Li\n"
        "N_STRUCTURES = 1\n",
    )

    with pytest.raises(InputFileError, match="规范化后相同"):
        parse_sqsincar(path)


def test_multi_formula_dry_run_summary_and_seed_offsets(tmp_path: Path) -> None:
    path = write_input(
        tmp_path,
        f"FORMULA = {FORMULA_001}\nFORMULA = {FORMULA_010}\nN_STRUCTURES = 5\n",
    )

    result = dry_run(path, load_settings(quality="high"), workers=2, base_seed=1234)

    assert result["status"] == "DRY_RUN"
    assert result["formula_count"] == 2
    assert len(result["jobs"]) == 2
    assert [job["seed"] for job in result["jobs"]] == [1234, 1001237]
    assert all(job["quality"] == "high" for job in result["jobs"])
    assert all(job["n_steps"] == 200000 for job in result["jobs"])
    assert [job["target_unique_pool"] for job in result["jobs"]] == [100, 100]
    assert all(job["max_sqs_runs"] == 2000 for job in result["jobs"])


def test_new_metals_include_rare_earth_in_composition() -> None:
    formula = parse_formula("O2Au0.1Nd0.1Pt0.1Ni0.7Li")
    plan = plan_composition(formula)

    assert formula.normalized == "LiNi0.7Au0.1Nd0.1Pt0.1O2"
    assert plan.actual_tm_counts == {"Ni": 21, "Au": 3, "Nd": 3, "Pt": 3}


@pytest.mark.parametrize("symbol", ["F", "Te", "Sb", "Xx"])
def test_rejects_nonmetals_metalloids_and_unknown_symbols(symbol: str) -> None:
    with pytest.raises(ElementError):
        parse_formula(f"LiNi0.9{symbol}0.1O2")


def test_ni_minimum_remains_0_6() -> None:
    assert parse_formula("LiNi0.6Nd0.4O2").tm_fractions["Ni"] == Decimal("0.6")
    with pytest.raises(NiContentError):
        parse_formula("LiNi0.59Nd0.41O2")


def test_quality_profiles_are_high_precision_and_adaptive() -> None:
    expected_steps = {"standard": 60000, "high": 200000, "ultra": 500000}
    for quality, n_steps in expected_steps.items():
        settings = load_settings(quality=quality)
        assert settings.quality == quality
        assert settings.n_steps == n_steps
        assert settings.batch_size in {32, 64}
        assert settings.min_unique_pool == QUALITY_PROFILES[quality]["min_unique_pool"]

    high = load_settings(quality="high")
    assert high.min_unique_pool == 50
    assert max(5 * high.oversample_factor, high.min_unique_pool) == 100
    assert high.max_sqs_runs >= 100
