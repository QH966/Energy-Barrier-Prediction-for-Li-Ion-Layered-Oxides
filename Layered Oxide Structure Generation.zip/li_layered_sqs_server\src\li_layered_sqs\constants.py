from decimal import Decimal

LEGACY_TM_ORDER = (
    "Ni", "Mn", "Co", "Al", "Ti", "Cu", "Ca", "Ce", "Mg", "Cr",
    "Fe", "Zr", "Bi", "Sb", "Nb", "W", "Ta", "Te", "V",
)
_LEGACY_RANK = {symbol: index for index, symbol in enumerate(LEGACY_TM_ORDER)}


def tm_sort_key(symbol: str) -> tuple[int, str]:
    return _LEGACY_RANK.get(symbol, len(_LEGACY_RANK)), symbol


def element_sort_key(symbol: str) -> tuple[int, int, str]:
    if symbol == "Li":
        return 0, 0, symbol
    if symbol == "O":
        return 2, 0, symbol
    rank, name = tm_sort_key(symbol)
    return 1, rank, name
NI_MIN = Decimal("0.6")
RESOLUTION_RULES = (
    (Decimal("0.10"), (5, 2, 1), 30),
    (Decimal("0.05"), (5, 4, 1), 60),
    (Decimal("0.01"), (3, 11, 1), 99),
)
