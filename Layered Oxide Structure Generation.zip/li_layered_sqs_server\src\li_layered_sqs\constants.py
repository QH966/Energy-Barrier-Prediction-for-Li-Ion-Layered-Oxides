from decimal import Decimal

TM_SPECIES = (
    "Ni", "Mn", "Co", "Al", "Ti", "Cu", "Ca", "Ce", "Mg", "Cr",
    "Fe", "Zr", "Bi", "Sb", "Nb", "W", "Ta", "Te", "V",
)
CANONICAL_ORDER = ("Li", *TM_SPECIES, "O")
ALLOWED_ELEMENTS = frozenset(CANONICAL_ORDER)
NI_MIN = Decimal("0.6")
RESOLUTION_RULES = (
    (Decimal("0.10"), (5, 2, 1), 30),
    (Decimal("0.05"), (5, 4, 1), 60),
    (Decimal("0.01"), (3, 11, 1), 99),
)
