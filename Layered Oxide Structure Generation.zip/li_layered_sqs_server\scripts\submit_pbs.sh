#!/usr/bin/env bash
#PBS -N li_sqs
#PBS -l select=1:ncpus=32
#PBS -j oe
set -euo pipefail
cd "${PBS_O_WORKDIR:?}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"
export OMP_NUM_THREADS=1
WORKERS="${NCPUS:-32}"
exec "$PYTHON_BIN" "$ROOT/portable_runner.py" -i "${SQS_INPUT:-$ROOT/SQSINCAR}" --workers "$WORKERS"
