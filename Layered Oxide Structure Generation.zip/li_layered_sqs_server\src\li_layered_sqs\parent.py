from __future__ import annotations

import hashlib
from collections import Counter
from pathlib import Path

import numpy as np
from pymatgen.core import Structure

from .exceptions import NeighborShellError, ParentStructureError


def symbol(site) -> str:
    return site.specie.symbol


def atom_counts(structure: Structure) -> dict[str, int]:
    return dict(Counter(symbol(site) for site in structure))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_parent(path: Path) -> Structure:
    if not path.is_file():
        raise ParentStructureError(f"缺少 canonical POSCAR: {path}")
    parent = Structure.from_file(path)
    if len(parent) != 12 or atom_counts(parent) != {"Li": 3, "Ni": 3, "O": 6}:
        raise ParentStructureError(f"canonical POSCAR 必须为 Li3Ni3O6/12 atoms，实际 {atom_counts(parent)}/{len(parent)}")
    return parent


def neighbor_shells(parent: Structure) -> list[float]:
    ni_indices = [index for index, site in enumerate(parent) if symbol(site) == "Ni"]
    distances: list[float] = []
    for index in ni_indices:
        for neighbor in parent.get_neighbors(parent[index], 12.0):
            if symbol(neighbor) == "Ni" and neighbor.nn_distance > 1.0e-6:
                distances.append(float(neighbor.nn_distance))
    distances.sort()
    shells: list[float] = []
    for distance in distances:
        if not shells or abs(distance - shells[-1]) > 1.0e-4:
            shells.append(distance)
    if len(shells) < 4:
        raise NeighborShellError(f"仅识别到 {len(shells)} 个 Ni-Ni 壳层，需要至少 4 个")
    return shells


def make_supercell(parent: Structure, matrix: tuple[int, int, int]) -> Structure:
    supercell = parent.copy()
    supercell.make_supercell(matrix)
    return supercell


def periodic_distance(first: np.ndarray, second: np.ndarray) -> float:
    delta = np.abs((first % 1.0) - (second % 1.0))
    return float(np.max(np.minimum(delta, 1.0 - delta)))


def map_to_reference(reference: list[np.ndarray], candidate: list[np.ndarray], tolerance: float = 1.0e-6) -> list[int]:
    remaining = set(range(len(candidate)))
    mapping: list[int] = []
    for coord in reference:
        matches = [index for index in remaining if periodic_distance(coord, candidate[index]) <= tolerance]
        if len(matches) != 1:
            raise ParentStructureError(f"无法唯一映射固定母相位点，matches={matches}")
        match = matches[0]
        mapping.append(match)
        remaining.remove(match)
    if remaining:
        raise ParentStructureError("存在未映射位点")
    return mapping
