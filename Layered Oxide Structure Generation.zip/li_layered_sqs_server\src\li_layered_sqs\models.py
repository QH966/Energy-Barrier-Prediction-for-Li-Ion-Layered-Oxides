from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path


@dataclass(frozen=True)
class InputSpec:
    formula_texts: tuple[str, ...]
    n_structures: int
    source: Path
    snapshots: tuple[str, ...]


@dataclass(frozen=True)
class Formula:
    normalized: str
    amounts: dict[str, Decimal]
    tm_fractions: dict[str, Decimal]


@dataclass(frozen=True)
class CompositionPlan:
    formula: Formula
    resolution: Decimal
    supercell: tuple[int, int, int]
    tm_sites: int
    nominal_tm_counts: dict[str, int]
    actual_tm_counts: dict[str, int]
    raw_configuration_count: int


@dataclass(frozen=True)
class Settings:
    exact_enumeration_limit: int = 200000
    quality: str = "high"
    oversample_factor: int = 20
    min_unique_pool: int = 50
    batch_size: int = 64
    max_sqs_runs: int = 2000
    n_steps: int = 200000
    t_start: float = 5.0
    t_stop: float = 0.001
    optimality_weight: float = 1.0
    tolerance: float = 1.0e-5
