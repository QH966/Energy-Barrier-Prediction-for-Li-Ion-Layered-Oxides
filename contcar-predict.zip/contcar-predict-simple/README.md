# CONTCAR Predict

Predict in-plane Li migration barriers (eV) from CONTCAR files, individually or recursively in batches.

## Install

Run inside this folder with Python 3.10+:

```bash
python -m pip install -r requirements.txt
```

## Batch CSV / Excel

```bash
python predict.py "path/to/structures" -o results.csv
python predict.py "path/to/structures" -o results.xlsx
```

## Example

```bash
python predict.py examples/sample/CONTCAR -o example_predictions.csv
```

Input: layered lithium-containing oxide structures in VASP format, named exactly `CONTCAR`, with Li layers in the ab plane and at least two Li sites.

Extraction errors or inputs without valid paths stop the entire batch without saving predictions. Existing output files are never overwritten; choose a new output filename.
