#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
batch_original_CONTCAR_all_ODH_paths_2plus6params.py

合并版：先从每个原始 CONTCAR 提取 2 个全局特征，再枚举层内 ODH/Li 迁移路径；局域环境相似的路径合并为同一路径代表，并输出 6 个路径特征。

核心逻辑：
    原始 CONTCAR 同时包含迁移路径起点 Li 和终点 Li。
    对于一条路径 start -> end：
        initial 虚拟初态 = 原始结构删除 end Li，保留 start Li
        final   虚拟末态 = 在 initial 的同一原子编号上，把 start Li 坐标移动到 end Li 坐标
    这样 find_migrating_li() 仍然通过“初末态同编号 Li 最大位移”识别迁移 Li，
    后续特征提取完全沿用旧脚本逻辑，数值与用未弛豫 b/POSCAR、e/POSCAR 直接提取保持一致。

默认目录结构：
    selected_root/
        LiNiO2/
            CONTCAR
        LiCoO2/
            CONTCAR
        ...

也支持 selected_root 本身就是单个材料文件夹，且其中直接有 CONTCAR。

输出：
    selected_root/ODH_original_CONTCAR_all_paths_2plus6params_时间戳.xlsx
        sheet: features
        第一列 formula，值为 LiNiO2_path1、LiNiO2_path2 ...
        后续输出 2 个材料级全局特征和 6 个路径特征，共 8 个特征。

    selected_root/ODH_original_CONTCAR_all_paths_2plus6params_时间戳_batch_log.txt
        记录每个材料、每条路径的原始 Li index、距离、状态。

依赖：
    pip install pymatgen numpy pandas openpyxl

重要参数：
    LI_PATH_MAX_DISTANCE 控制从原始 CONTCAR 中枚举 Li-Li 迁移候选路径的最大距离。
    对层状氧化物常见近邻 Li 跳跃，默认 4.00 Å；如你的 ODH 定义更严格，可改小。
"""

import os
import sys
import re
import math
import traceback
from datetime import datetime

import numpy as np
import pandas as pd

from pymatgen.core import Structure
from pymatgen.core.periodic_table import Element
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


# =========================
# 参数区：需要时改这里
# =========================
ORIGINAL_STRUCTURE_NAME = "CONTCAR"
FALLBACK_STRUCTURE_NAMES = ["CONTCAR", "POSCAR"]

EXCEL_PREFIX = "ODH_original_CONTCAR_all_paths_2plus6params"
BATCH_LOG_SUFFIX = "_batch_log.txt"

# 如果设为 True，会在每个材料文件夹下写出 virtual_ODH_endpoints/formula_pathN/b/POSCAR 和 e/POSCAR。
# 特征计算本身不依赖落盘；默认 False，避免产生大量文件。
WRITE_VIRTUAL_ENDPOINTS = False
VIRTUAL_ENDPOINT_ROOT_NAME = "virtual_ODH_endpoints"
POSCAR_NAME = "POSCAR"

# 从原始 CONTCAR 枚举 ODH/Li 路径的 Li-Li 距离范围。
# 下限沿用旧脚本迁移 Li 最小位移阈值；上限按层状材料近邻 Li 跳跃给默认值。
MIN_MIGRATION_DISTANCE = 0.30  # Å
LI_PATH_MIN_DISTANCE = MIN_MIGRATION_DISTANCE
LI_PATH_MAX_DISTANCE = 4.00  # Å

# 层内 ODH 迁移约束：
# 你的 ODH 路径定义为层内迁移，因此候选 Li-Li pair 不能明显沿 c 轴迁移。
# 同时满足以下 3 个条件才保留：
#   1) c 轴方向位移分量 <= MAX_PATH_OUTPLANE_ABS
#   2) c 轴方向分量 / 总 Li-Li 距离 <= MAX_PATH_OUTPLANE_RATIO
#   3) 最近周期镜像下的分数 c 坐标差 <= MAX_PATH_DELTA_C_FRAC
# 如果你的结构层内 Li 有轻微弛豫，可适当放宽；若仍有跨层路径混入，可适当收紧。
FILTER_INPLANE_ONLY = True
MAX_PATH_OUTPLANE_ABS = 0.80      # Å
MAX_PATH_OUTPLANE_RATIO = 0.25    # dimensionless
MAX_PATH_DELTA_C_FRAC = 0.08      # fractional c

# 局域环境相似路径合并：
# 先按空间群去重，再按以下 5 个路径特征判断局域环境是否相似。
# 若某条路径与已有代表路径的所有差异都不超过对应 tolerance，则归为同一类。
MERGE_SIMILAR_ENVIRONMENT_PATHS = True
ENV_SIMILARITY_FEATURES = [
    "O_bottleneck_asymmetry",
    "wmean_cation_mendeleev_3p5",
    "distortion_LiO_end",
    "mean_M_O_6nearest",
    "d_LiLi_inplane",
]
ENV_SIMILARITY_TOLERANCES = {
    "O_bottleneck_asymmetry": 0.05,       # Å
    "wmean_cation_mendeleev_3p5": 1.00,   # Mendeleev number
    "distortion_LiO_end": 0.01,           # dimensionless
    "mean_M_O_6nearest": 0.05,            # Å
    "d_LiLi_inplane": 0.05,               # Å
}

# 是否用空间群操作去掉等价路径。
# 若掺杂/缺陷导致对称性为 P1，则基本不会合并路径。
USE_SYMMETRY_REDUCTION = True
SYMPREC = 1e-3
ANGLE_TOLERANCE = 5.0
SYM_SITE_MATCH_TOL = 0.10  # Å

# False：每条不等价 Li-Li pair 只输出一个方向，按原始 index 小 -> 大作为 canonical direction。
# True ：输出所有不等价有向路径；若对称操作能把 start->end 映射到 end->start，则仍会合并。
GENERATE_BOTH_DIRECTIONS = False

# 异侧氧瓶颈搜索半径；如果找不到，会自动扩展到 FALLBACK_O_SEARCH_RADIUS。
O_BOTTLENECK_RADIUS = 3.50  # Å
FALLBACK_O_SEARCH_RADIUS = 4.50  # Å

# Li-O / M-O 配位统计半径
O_CN_CUTOFF_1 = 2.80  # Å
O_CN_CUTOFF_2 = 3.00  # Å

# 局域阳离子环境半径：非 Li / 非 O 都看作局域阳离子特征来源
CATION_RADIUS = 3.50  # Å

# 局域 Li 拥挤程度半径
LI_DENSITY_RADIUS = 4.00  # Å

# 异侧判断时，side 值过小表示 O 几乎在线上，默认不作为异侧候选
SIDE_EPS = 1e-8


FEATURE_COLUMNS = [
    "formula",
    "valid",
    "n_atoms",
    "n_Li",
    "n_O",
    "n_cations",

    # 路径几何
    "d_LiLi",
    "d_LiLi_inplane",
    "d_LiLi_outplane_abs",
    "outplane_ratio",
    "delta_c_frac",
    "mid_frac_a",
    "mid_frac_b",
    "mid_frac_c",

    # 异侧氧瓶颈
    "O_side_valid",
    "d_OO_bottleneck_opposite",
    "d_mid_O1",
    "d_mid_O2",
    "d_mid_O_min",
    "d_mid_O_mean",
    "O_bottleneck_asymmetry",
    "O_path_projection_abs_mean",
    "O_gate_balance",

    # 迁移中点虚拟 Li-O 环境
    "CN_O_mid_2p8",
    "CN_O_mid_3p0",
    "min_M_O",
    "mean_M_O_4nearest",
    "std_M_O_4nearest",
    "distortion_MO_4nearest",
    "mean_M_O_6nearest",
    "std_M_O_6nearest",
    "distortion_MO_6nearest",

    # 初态 / 末态 Li-O 环境
    "CN_O_start_2p8",
    "CN_O_end_2p8",
    "min_LiO_start",
    "min_LiO_end",
    "mean_LiO_start_4nearest",
    "mean_LiO_end_4nearest",
    "std_LiO_start_4nearest",
    "std_LiO_end_4nearest",
    "distortion_LiO_start",
    "distortion_LiO_end",
    "delta_mean_LiO",
    "delta_distortion_LiO",

    # 局域 Li 拥挤程度
    "nearest_Li_to_mid",
    "num_Li_mid_3p0",
    "num_Li_mid_3p5",
    "local_Li_density_4p0",

    # 局域氧框架几何
    "nearest_OO_around_mid",
    "mean_OO_6nearest_pairs",
    "std_OO_6nearest_pairs",
    "O_layer_thickness_local",
    "O_plane_deviation",

    # 局域非 Li/O 阳离子几何
    "nearest_cation_distance",
    "mean_cation_distance_3p5",
    "std_cation_distance_3p5",
    "num_cation_3p5",

    # 局域阳离子元素物性统计：跨材料数值化，不直接用元素名
    "mean_cation_Z_3p5",
    "std_cation_Z_3p5",
    "wmean_cation_Z_3p5",
    "mean_cation_X_3p5",
    "std_cation_X_3p5",
    "wmean_cation_X_3p5",
    "mean_cation_atomic_radius_3p5",
    "std_cation_atomic_radius_3p5",
    "wmean_cation_atomic_radius_3p5",
    "mean_cation_mendeleev_3p5",
    "std_cation_mendeleev_3p5",
    "wmean_cation_mendeleev_3p5",
    "mean_cation_group_3p5",
    "std_cation_group_3p5",
    "wmean_cation_group_3p5",
    "mean_cation_row_3p5",
    "std_cation_row_3p5",
    "wmean_cation_row_3p5",
]

NUMERIC_COLUMNS = [c for c in FEATURE_COLUMNS if c != "formula"]

# 最终 Excel 输出 2 个材料级全局特征 + 6 个层内路径特征。
# 先输出两个从完整原始 CONTCAR 提取的全局特征；
# 后面输出针对每条 ODH/Li 路径计算的 6 个特征，其中新增 O-O 瓶颈距离。
OUTPUT_GLOBAL_FEATURE_COLUMNS = [
    "a_times_b",
    "Li_to_transition_metal_ratio",
]

OUTPUT_PATH_FEATURE_COLUMNS = [
    "d_OO_bottleneck_opposite",  # O-O 瓶颈距离，单位 Å
    "O_bottleneck_asymmetry",
    "wmean_cation_mendeleev_3p5",
    "distortion_LiO_end",
    "mean_M_O_6nearest",
    "d_LiLi_inplane",
]

OUTPUT_FEATURE_COLUMNS = OUTPUT_GLOBAL_FEATURE_COLUMNS + OUTPUT_PATH_FEATURE_COLUMNS
OUTPUT_COLUMNS = ["formula"] + OUTPUT_FEATURE_COLUMNS
OUTPUT_NUMERIC_COLUMNS = OUTPUT_FEATURE_COLUMNS[:]


def safe_float(x):
    """把 None / nan / inf 转成 0，保证 Excel 全是可训练数值。"""
    try:
        v = float(x)
        if math.isnan(v) or math.isinf(v):
            return 0.0
        return v
    except Exception:
        return 0.0


def zero_row(formula):
    row = {"formula": formula}
    for col in NUMERIC_COLUMNS:
        row[col] = 0.0
    return row


# =========================
# 两个全局特征：a*b 晶格面积特征 + Li/TM 组成比例，均直接基于完整原始 CONTCAR 计算
# =========================
TRANSITION_METALS = {
    "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
    "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd",
    "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg",
}


def clean_symbol_for_global_features(x):
    """提取标准元素符号，兼容字符串、Element/Species 等对象。"""
    if hasattr(x, "symbol"):
        x = x.symbol
    m = re.match(r"([A-Z][a-z]?)", str(x))
    return m.group(1) if m else str(x)


def site_contains_for_global_features(site, symbol):
    """判断 site 或 Neighbor 是否含指定元素，兼容有序/部分无序结构。"""
    try:
        for sp in site.species:
            if clean_symbol_for_global_features(sp) == symbol:
                return True
    except Exception:
        try:
            return clean_symbol_for_global_features(site.specie) == symbol
        except Exception:
            return False
    return False


def get_Li_to_transition_metal_ratio(struct):
    """Li_to_transition_metal_ratio = n_Li / n_transition_metal。"""
    try:
        comp = struct.composition.element_composition.as_dict()
    except Exception:
        return 0.0

    amounts = {}
    for key, value in comp.items():
        sym = clean_symbol_for_global_features(key)
        amounts[sym] = amounts.get(sym, 0.0) + safe_float(value)

    n_li = amounts.get("Li", 0.0)
    n_tm = sum(v for e, v in amounts.items() if e in TRANSITION_METALS)
    return safe_float(n_li / n_tm) if n_tm > 1e-12 else 0.0


def get_Li_CN_nonLi_4A_max(struct, search_radius=10.0, cutoff=4.0):
    """
    对完整结构中每个 Li 位点，在 PBC 下统计 cutoff 内非 Li 邻居数，
    最后取所有 Li 位点中的最大值。
    """
    li_indices = [i for i, site in enumerate(struct) if site_contains_for_global_features(site, "Li")]
    if not li_indices:
        return 0.0

    cn_values = []
    for i in li_indices:
        c = 0
        for nb in struct.get_neighbors(struct[i], r=search_radius):
            d = safe_float(getattr(nb, "nn_distance", 0.0))
            if d < 1e-8:
                continue
            if (d <= cutoff) and (not site_contains_for_global_features(nb, "Li")):
                c += 1
        cn_values.append(c)

    return safe_float(np.max(cn_values)) if cn_values else 0.0


def get_a_times_b(struct):
    """a_times_b = 晶格常数 a 与 b 的乘积，单位 Å^2。"""
    try:
        a = safe_float(struct.lattice.a)
        b = safe_float(struct.lattice.b)
        return safe_float(a * b)
    except Exception:
        return 0.0


def extract_global_Li_features(struct):
    """返回两个全局特征，供同一材料的所有 path 行重复填入。"""
    return {
        "a_times_b": get_a_times_b(struct),
        "Li_to_transition_metal_ratio": get_Li_to_transition_metal_ratio(struct),
    }


# =========================
# 局域环境相似路径合并
# =========================
def rows_are_environment_similar(row_a, row_b):
    """按 ENV_SIMILARITY_FEATURES + tolerance 判断两条 path 局域环境是否相似。"""
    for col in ENV_SIMILARITY_FEATURES:
        tol = safe_float(ENV_SIMILARITY_TOLERANCES.get(col, 0.0))
        va = safe_float(row_a.get(col, 0.0))
        vb = safe_float(row_b.get(col, 0.0))
        if abs(va - vb) > tol:
            return False
    return True


def merge_similar_environment_paths(path_records):
    """
    将局域环境相似的路径归为同一类。

    path_records 中每个元素至少包含：
        label, row, start_idx, end_idx, distance
    返回 groups，每组包含 representative 和 members。
    """
    if not MERGE_SIMILAR_ENVIRONMENT_PATHS:
        return [{"representative": rec, "members": [rec]} for rec in path_records]

    groups = []
    for rec in path_records:
        matched = False
        for group in groups:
            rep = group["representative"]
            if rows_are_environment_similar(rec["row"], rep["row"]):
                group["members"].append(rec)
                matched = True
                break

        if not matched:
            groups.append({
                "representative": rec,
                "members": [rec],
            })

    return groups


def build_group_output_row(formula, group_index, group, global_feats):
    """
    对同一类局域环境相似 path 输出一行。
    全局特征直接使用材料值；路径特征取组内均值，降低等价/近等价 path 的局部波动。
    """
    members = group["members"]
    out_row = {"formula": f"{formula}_path{group_index}"}

    for col in OUTPUT_GLOBAL_FEATURE_COLUMNS:
        out_row[col] = safe_float(global_feats.get(col, 0.0))

    for col in OUTPUT_PATH_FEATURE_COLUMNS:
        vals = [safe_float(member["row"].get(col, 0.0)) for member in members]
        out_row[col] = safe_float(np.mean(vals)) if vals else 0.0

    return out_row


def site_element(site):
    """返回站点主元素符号。POSCAR/CONTCAR 通常是有序结构。"""
    try:
        return site.specie.symbol
    except Exception:
        try:
            return site.species.elements[0].symbol
        except Exception:
            return str(site.species_string)


def is_li(site):
    return site_element(site) == "Li"


def is_o(site):
    return site_element(site) == "O"


def is_cation_for_features(site):
    """局域阳离子特征：排除 Li 和 O，其余元素都作为跨材料局域化学环境来源。"""
    e = site_element(site)
    return e not in {"Li", "O"}


def pbc_vector_from_anchor(lattice, anchor_frac, target_frac):
    """
    从 anchor 指向 target 最近周期镜像的向量。

    Returns
    -------
    distance : float
    image : np.ndarray[int]
        target 需要加上的周期镜像。
    target_frac_image : np.ndarray
    vector_cart : np.ndarray
        anchor -> target_image 的笛卡尔向量。
    """
    anchor_frac = np.asarray(anchor_frac, dtype=float)
    target_frac = np.asarray(target_frac, dtype=float)
    distance, image = lattice.get_distance_and_image(anchor_frac, target_frac)
    image = np.asarray(image, dtype=int)
    target_frac_image = target_frac + image
    vector_frac = target_frac_image - anchor_frac
    vector_cart = lattice.get_cartesian_coords(vector_frac)
    return float(distance), image, target_frac_image, np.asarray(vector_cart, dtype=float)


def unit_vector(vec):
    vec = np.asarray(vec, dtype=float)
    n = np.linalg.norm(vec)
    if n < 1e-12:
        return vec * 0.0
    return vec / n


def get_lattice_c_unit(lattice):
    c_vec = np.asarray(lattice.matrix[2], dtype=float)
    n = np.linalg.norm(c_vec)
    if n < 1e-12:
        return np.array([0.0, 0.0, 1.0])
    return c_vec / n


def count_elements(struct):
    n_li = 0
    n_o = 0
    n_cation = 0
    for site in struct:
        if is_li(site):
            n_li += 1
        elif is_o(site):
            n_o += 1
        else:
            n_cation += 1
    return n_li, n_o, n_cation


def find_migrating_li(initial, final):
    """通过初末态同编号 Li 位移，识别迁移 Li。该函数保持旧脚本逻辑。"""
    if len(initial) != len(final):
        raise ValueError(f"初态和末态原子数不同：{len(initial)} vs {len(final)}")

    candidates = []
    for idx, site in enumerate(initial):
        if not is_li(site):
            continue
        if not is_li(final[idx]):
            continue
        d, image, end_frac_image, v_cart = pbc_vector_from_anchor(
            initial.lattice,
            site.frac_coords,
            final[idx].frac_coords,
        )
        candidates.append((d, idx, image, end_frac_image, v_cart))

    if not candidates:
        raise ValueError("没有找到初末态同编号 Li。请检查虚拟端点构造或元素顺序。")

    candidates.sort(reverse=True, key=lambda x: x[0])
    max_d, idx, image, end_frac_image, v_cart = candidates[0]

    if max_d < MIN_MIGRATION_DISTANCE:
        raise ValueError(
            f"最大 Li 位移只有 {max_d:.4f} Å，小于阈值 {MIN_MIGRATION_DISTANCE:.2f} Å；"
            "无法可靠识别迁移 Li。"
        )

    return {
        "index": idx,
        "distance": float(max_d),
        "image": image,
        "start_frac": np.asarray(initial[idx].frac_coords, dtype=float),
        "end_frac": np.asarray(final[idx].frac_coords, dtype=float),
        "end_frac_image": np.asarray(end_frac_image, dtype=float),
        "vector_cart": np.asarray(v_cart, dtype=float),
    }


def distances_from_point(struct, anchor_frac, selector, exclude_indices=None):
    """返回 anchor 到满足 selector 的站点距离列表。"""
    if exclude_indices is None:
        exclude_indices = set()
    else:
        exclude_indices = set(exclude_indices)

    out = []
    for idx, site in enumerate(struct):
        if idx in exclude_indices:
            continue
        if not selector(site):
            continue
        d, image, frac_img, vec_cart = pbc_vector_from_anchor(
            struct.lattice,
            anchor_frac,
            site.frac_coords,
        )
        out.append({
            "index": idx,
            "element": site_element(site),
            "distance": float(d),
            "image": image,
            "frac": np.asarray(site.frac_coords, dtype=float),
            "frac_image": np.asarray(frac_img, dtype=float),
            "vec_cart": np.asarray(vec_cart, dtype=float),
        })
    out.sort(key=lambda x: x["distance"])
    return out


def nearest_stats(distances, n):
    vals = [x["distance"] for x in distances[:n]]
    if len(vals) == 0:
        return 0.0, 0.0, 0.0
    vals = np.asarray(vals, dtype=float)
    mean = float(np.mean(vals))
    std = float(np.std(vals))
    distortion = float(std / mean) if mean > 1e-12 else 0.0
    return mean, std, distortion


def coord_number(distances, cutoff):
    return float(sum(1 for x in distances if x["distance"] <= cutoff))


def min_distance(distances):
    return float(distances[0]["distance"]) if distances else 0.0


def select_opposite_side_oxygen_pair(struct, mid_frac, migration_vec_cart):
    """
    选择位于迁移路径两侧的 O-O 瓶颈对。保持旧脚本逻辑。
    """
    lattice = struct.lattice
    c_unit = get_lattice_c_unit(lattice)

    v_cart = np.asarray(migration_vec_cart, dtype=float)
    v_inplane = v_cart - np.dot(v_cart, c_unit) * c_unit
    if np.linalg.norm(v_inplane) < 1e-10:
        v_inplane = v_cart.copy()
    v_unit = unit_vector(v_inplane)
    if np.linalg.norm(v_unit) < 1e-10:
        raise ValueError("迁移向量长度过小，无法判断异侧氧。")

    def build_candidates(radius):
        oxy = distances_from_point(struct, mid_frac, is_o)
        candidates = []
        for item in oxy:
            if item["distance"] > radius:
                continue
            r = item["vec_cart"]
            r_inplane = r - np.dot(r, c_unit) * c_unit
            side_value = float(np.dot(c_unit, np.cross(v_unit, r_inplane)))
            if abs(side_value) < SIDE_EPS:
                side = 0
            elif side_value > 0:
                side = 1
            else:
                side = -1
            path_projection = float(np.dot(r_inplane, v_unit))
            perp_vec = r_inplane - path_projection * v_unit
            perp_distance = float(np.linalg.norm(perp_vec))
            new_item = dict(item)
            new_item.update({
                "side_value": side_value,
                "side": side,
                "path_projection": path_projection,
                "perp_distance": perp_distance,
            })
            candidates.append(new_item)
        return candidates

    chosen = None
    side_valid = 0.0
    used_radius = O_BOTTLENECK_RADIUS

    for radius in [O_BOTTLENECK_RADIUS, FALLBACK_O_SEARCH_RADIUS]:
        candidates = build_candidates(radius)
        pair_scores = []
        for i in range(len(candidates)):
            for j in range(i + 1, len(candidates)):
                a = candidates[i]
                b = candidates[j]
                if a["side"] == 0 or b["side"] == 0:
                    continue
                if a["side"] * b["side"] >= 0:
                    continue

                proj_penalty = abs(a["path_projection"]) + abs(b["path_projection"])
                balance_penalty = abs(a["perp_distance"] - b["perp_distance"])
                score = (
                    a["distance"] + b["distance"]
                    + 0.25 * proj_penalty
                    + 0.15 * balance_penalty
                )
                pair_scores.append((score, a, b))

        if pair_scores:
            pair_scores.sort(key=lambda x: x[0])
            chosen = (pair_scores[0][1], pair_scores[0][2])
            side_valid = 1.0
            used_radius = radius
            break

    if chosen is None:
        all_oxy = build_candidates(FALLBACK_O_SEARCH_RADIUS)
        all_oxy.sort(key=lambda x: x["distance"])
        if len(all_oxy) < 2:
            return None
        chosen = (all_oxy[0], all_oxy[1])
        side_valid = 0.0
        used_radius = FALLBACK_O_SEARCH_RADIUS

    o1, o2 = chosen
    d_oo, _, _, _ = pbc_vector_from_anchor(lattice, o1["frac"], o2["frac"])
    d1 = float(o1["distance"])
    d2 = float(o2["distance"])
    perp_sum = o1["perp_distance"] + o2["perp_distance"]
    gate_balance = abs(o1["perp_distance"] - o2["perp_distance"]) / perp_sum if perp_sum > 1e-12 else 0.0

    return {
        "O_side_valid": side_valid,
        "used_radius": used_radius,
        "o1": o1,
        "o2": o2,
        "d_OO": float(d_oo),
        "d_mid_O1": d1,
        "d_mid_O2": d2,
        "d_mid_O_min": min(d1, d2),
        "d_mid_O_mean": 0.5 * (d1 + d2),
        "asymmetry": abs(d1 - d2),
        "path_projection_abs_mean": 0.5 * (abs(o1["path_projection"]) + abs(o2["path_projection"])),
        "gate_balance": float(gate_balance),
    }


def pairwise_distances_among_sites(struct, items):
    vals = []
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            d, _, _, _ = pbc_vector_from_anchor(
                struct.lattice,
                items[i]["frac"],
                items[j]["frac"],
            )
            vals.append(float(d))
    vals.sort()
    return vals


def local_oxygen_framework_features(struct, mid_frac):
    oxy = distances_from_point(struct, mid_frac, is_o)
    nearest6 = oxy[:6]

    result = {
        "nearest_OO_around_mid": 0.0,
        "mean_OO_6nearest_pairs": 0.0,
        "std_OO_6nearest_pairs": 0.0,
        "O_layer_thickness_local": 0.0,
        "O_plane_deviation": 0.0,
    }

    if len(nearest6) >= 2:
        pair_d = pairwise_distances_among_sites(struct, nearest6)
        if pair_d:
            result["nearest_OO_around_mid"] = float(np.min(pair_d))
            result["mean_OO_6nearest_pairs"] = float(np.mean(pair_d))
            result["std_OO_6nearest_pairs"] = float(np.std(pair_d))

    if len(nearest6) >= 3:
        c_unit = get_lattice_c_unit(struct.lattice)
        vecs = np.asarray([x["vec_cart"] for x in nearest6], dtype=float)
        c_proj = vecs @ c_unit
        result["O_layer_thickness_local"] = float(np.max(c_proj) - np.min(c_proj))

        centered = vecs - np.mean(vecs, axis=0)
        try:
            _, _, vh = np.linalg.svd(centered, full_matrices=False)
            normal = vh[-1]
            signed = centered @ normal
            result["O_plane_deviation"] = float(np.sqrt(np.mean(signed ** 2)))
        except Exception:
            result["O_plane_deviation"] = 0.0

    return result, oxy


def get_element_properties(symbol):
    """返回跨材料数值元素属性。缺失值填 0。"""
    try:
        el = Element(symbol)
    except Exception:
        return {
            "Z": 0.0,
            "X": 0.0,
            "atomic_radius": 0.0,
            "mendeleev": 0.0,
            "group": 0.0,
            "row": 0.0,
        }

    radius = getattr(el, "atomic_radius", None)
    if radius is None:
        radius = getattr(el, "atomic_radius_calculated", None)

    return {
        "Z": safe_float(getattr(el, "Z", 0.0)),
        "X": safe_float(getattr(el, "X", 0.0)),
        "atomic_radius": safe_float(radius),
        "mendeleev": safe_float(getattr(el, "mendeleev_no", 0.0)),
        "group": safe_float(getattr(el, "group", 0.0)),
        "row": safe_float(getattr(el, "row", 0.0)),
    }


def mean_std_wmean(values, weights):
    values = np.asarray(values, dtype=float)
    weights = np.asarray(weights, dtype=float)
    if len(values) == 0:
        return 0.0, 0.0, 0.0
    mean = float(np.mean(values))
    std = float(np.std(values))
    if np.sum(weights) > 1e-12:
        wmean = float(np.sum(values * weights) / np.sum(weights))
    else:
        wmean = mean
    return mean, std, wmean


def local_cation_features(struct, mid_frac):
    cations = distances_from_point(struct, mid_frac, is_cation_for_features)
    local = [x for x in cations if x["distance"] <= CATION_RADIUS]

    result = {
        "nearest_cation_distance": min_distance(cations),
        "mean_cation_distance_3p5": 0.0,
        "std_cation_distance_3p5": 0.0,
        "num_cation_3p5": float(len(local)),
    }

    if local:
        dists = np.asarray([x["distance"] for x in local], dtype=float)
        result["mean_cation_distance_3p5"] = float(np.mean(dists))
        result["std_cation_distance_3p5"] = float(np.std(dists))

    prop_names = ["Z", "X", "atomic_radius", "mendeleev", "group", "row"]
    prop_values = {name: [] for name in prop_names}
    weights = []

    for item in local:
        props = get_element_properties(item["element"])
        weights.append(1.0 / max(item["distance"], 1e-6))
        for name in prop_names:
            prop_values[name].append(props[name])

    for name in prop_names:
        mean, std, wmean = mean_std_wmean(prop_values[name], weights)
        if name == "atomic_radius":
            base = "cation_atomic_radius"
        elif name == "mendeleev":
            base = "cation_mendeleev"
        else:
            base = f"cation_{name}"
        result[f"mean_{base}_3p5"] = mean
        result[f"std_{base}_3p5"] = std
        result[f"wmean_{base}_3p5"] = wmean

    return result, local, cations


# =========================
# 新增：从原始 CONTCAR 枚举不等价 ODH/Li 路径
# =========================
def locate_original_structure(material_dir):
    """在材料文件夹中寻找原始 CONTCAR；若不存在，按 FALLBACK_STRUCTURE_NAMES 兜底。"""
    preferred = os.path.join(material_dir, ORIGINAL_STRUCTURE_NAME)
    if os.path.isfile(preferred):
        return preferred
    for name in FALLBACK_STRUCTURE_NAMES:
        p = os.path.join(material_dir, name)
        if os.path.isfile(p):
            return p
    return None


def get_material_dirs(root_dir):
    """
    支持两种输入：
        1) root/formula/CONTCAR
        2) root/CONTCAR
    """
    root_dir = os.path.abspath(root_dir)
    if locate_original_structure(root_dir) is not None:
        return [(os.path.basename(root_dir.rstrip(os.sep)), root_dir)]

    subdirs = [
        name for name in os.listdir(root_dir)
        if os.path.isdir(os.path.join(root_dir, name)) and not name.startswith(".")
    ]
    subdirs.sort()
    return [(name, os.path.join(root_dir, name)) for name in subdirs]


def li_site_indices(struct):
    return [idx for idx, site in enumerate(struct) if is_li(site)]


def find_matching_li_index(struct, frac, li_indices, tol=SYM_SITE_MATCH_TOL):
    """
    把对称操作后的 Li frac 坐标匹配回原结构 Li index。
    用真实 PBC 距离匹配，避免 frac 边界导致误判。
    """
    best_idx = None
    best_d = 1e99
    for idx in li_indices:
        d, _, _, _ = pbc_vector_from_anchor(struct.lattice, frac, struct[idx].frac_coords)
        if d < best_d:
            best_d = d
            best_idx = idx
    if best_idx is None or best_d > tol:
        return None
    return best_idx


def build_li_symmetry_permutations(struct):
    """
    构造所有可用空间群操作对 Li site index 的置换。
    如果失败或没有有效对称操作，返回 identity permutation。
    """
    li_idx = li_site_indices(struct)
    identity = {i: i for i in li_idx}

    if not USE_SYMMETRY_REDUCTION:
        return [identity]

    try:
        sga = SpacegroupAnalyzer(struct, symprec=SYMPREC, angle_tolerance=ANGLE_TOLERANCE)
        ops = sga.get_symmetry_operations(cartesian=False)
    except Exception:
        return [identity]

    perms = []
    seen = set()

    for op in ops:
        mapping = {}
        ok = True
        for i in li_idx:
            frac_new = np.mod(op.operate(struct[i].frac_coords), 1.0)
            j = find_matching_li_index(struct, frac_new, li_idx, tol=SYM_SITE_MATCH_TOL)
            if j is None:
                ok = False
                break
            mapping[i] = j

        if not ok:
            continue

        key = tuple(mapping[i] for i in li_idx)
        if key not in seen:
            seen.add(key)
            perms.append(mapping)

    if not perms:
        perms = [identity]

    return perms


def canonical_path_key(start_idx, end_idx, li_perms, directed=False):
    """
    对路径做对称归一化。
        directed=False：Li-Li pair 视为无向路径，(i,j) 与 (j,i) 合并。
        directed=True ：保留方向；但若空间群操作能把两个方向互相映射，则仍合并。
    """
    keys = []
    for perm in li_perms:
        if start_idx not in perm or end_idx not in perm:
            continue
        a = perm[start_idx]
        b = perm[end_idx]
        if not directed and a > b:
            a, b = b, a
        keys.append((a, b))
    if not keys:
        a, b = start_idx, end_idx
        if not directed and a > b:
            a, b = b, a
        return (a, b)
    return min(keys)


def is_inplane_layer_migration_path(struct, start_frac, end_frac_image, vector_cart):
    """
    判断 Li-Li pair 是否属于层内迁移。

    层内 ODH 路径不应具有明显 c 轴迁移分量。
    这里同时使用真实笛卡尔 c 轴投影、outplane ratio 和分数 c 坐标差进行筛选。
    """
    if not FILTER_INPLANE_ONLY:
        return True

    v = np.asarray(vector_cart, dtype=float)
    d_total = float(np.linalg.norm(v))
    if d_total < 1e-12:
        return False

    c_unit = get_lattice_c_unit(struct.lattice)
    d_out_abs = abs(float(np.dot(v, c_unit)))
    outplane_ratio = d_out_abs / d_total
    delta_c_frac = abs(float(np.asarray(end_frac_image, dtype=float)[2] - np.asarray(start_frac, dtype=float)[2]))

    return (
        d_out_abs <= MAX_PATH_OUTPLANE_ABS
        and outplane_ratio <= MAX_PATH_OUTPLANE_RATIO
        and delta_c_frac <= MAX_PATH_DELTA_C_FRAC
    )


def enumerate_inequivalent_odh_paths(original):
    """
    从原始结构中枚举 Li-Li 近邻迁移路径，并通过空间群操作去掉等价路径。

    返回列表中每个元素包含：
        start_idx, end_idx, distance, image, end_frac_image, vector_cart
    """
    li_idx = li_site_indices(original)
    if len(li_idx) < 2:
        return []

    li_perms = build_li_symmetry_permutations(original)

    raw_paths = []
    for a in range(len(li_idx)):
        for b in range(a + 1, len(li_idx)):
            i = li_idx[a]
            j = li_idx[b]
            d, image, end_frac_image, v_cart = pbc_vector_from_anchor(
                original.lattice,
                original[i].frac_coords,
                original[j].frac_coords,
            )

            if d < LI_PATH_MIN_DISTANCE or d > LI_PATH_MAX_DISTANCE:
                continue

            if not is_inplane_layer_migration_path(
                original,
                original[i].frac_coords,
                end_frac_image,
                v_cart,
            ):
                continue

            if GENERATE_BOTH_DIRECTIONS:
                raw_paths.append({
                    "start_idx": i,
                    "end_idx": j,
                    "distance": float(d),
                    "image": image,
                    "end_frac_image": end_frac_image,
                    "vector_cart": v_cart,
                })
                d2, image2, end_frac_image2, v_cart2 = pbc_vector_from_anchor(
                    original.lattice,
                    original[j].frac_coords,
                    original[i].frac_coords,
                )
                if is_inplane_layer_migration_path(
                    original,
                    original[j].frac_coords,
                    end_frac_image2,
                    v_cart2,
                ):
                    raw_paths.append({
                        "start_idx": j,
                        "end_idx": i,
                        "distance": float(d2),
                        "image": image2,
                        "end_frac_image": end_frac_image2,
                        "vector_cart": v_cart2,
                    })
            else:
                raw_paths.append({
                    "start_idx": i,
                    "end_idx": j,
                    "distance": float(d),
                    "image": image,
                    "end_frac_image": end_frac_image,
                    "vector_cart": v_cart,
                })

    unique = {}
    directed = bool(GENERATE_BOTH_DIRECTIONS)
    for path in raw_paths:
        key = canonical_path_key(path["start_idx"], path["end_idx"], li_perms, directed=directed)
        # 若多个原始 pair 对称等价，保留 index 字典序最小、距离最小的代表，保证 path 编号稳定。
        rank = (
            int(path["start_idx"]),
            int(path["end_idx"]),
            round(float(path["distance"]), 8),
        )
        if key not in unique or rank < unique[key]["_rank"]:
            path2 = dict(path)
            path2["_rank"] = rank
            unique[key] = path2

    paths = list(unique.values())
    for p in paths:
        p.pop("_rank", None)

    paths.sort(key=lambda x: (int(x["start_idx"]), int(x["end_idx"]), float(x["distance"])))
    return paths


def ordered_species_for_site(site):
    """
    Structure 构造时使用站点 species。
    有序 POSCAR/CONTCAR 下 site.specie 最干净；若异常则回退到 species。
    """
    try:
        return site.specie
    except Exception:
        return site.species


def build_virtual_endpoints_from_original(original, start_idx, end_idx):
    """
    从原始 CONTCAR 构造虚拟初末态。

    initial = 删除 end_idx，对应“去掉迁移路径终点”；
    final   = 与 initial 完全同序，但 start_idx 这一同编号 Li 被移动到 end_idx 的坐标，
              对应“去掉迁移路径起点”后的末态，只是重新编号以满足旧脚本同编号 Li 位移识别。

    返回：
        initial, final, start_virtual_index
    """
    if start_idx == end_idx:
        raise ValueError("start_idx 与 end_idx 相同，无法构造路径。")
    if not is_li(original[start_idx]) or not is_li(original[end_idx]):
        raise ValueError(f"路径端点不是 Li: start={start_idx}, end={end_idx}")

    kept_indices = [idx for idx in range(len(original)) if idx != end_idx]
    if start_idx not in kept_indices:
        raise ValueError("删除终点后起点不存在，构造失败。")

    species = []
    initial_frac = []
    final_frac = []

    end_frac = np.asarray(original[end_idx].frac_coords, dtype=float)

    for idx in kept_indices:
        site = original[idx]
        species.append(ordered_species_for_site(site))
        initial_frac.append(np.asarray(site.frac_coords, dtype=float))

        if idx == start_idx:
            final_frac.append(end_frac.copy())
        else:
            final_frac.append(np.asarray(site.frac_coords, dtype=float))

    initial = Structure(original.lattice, species, initial_frac, coords_are_cartesian=False)
    final = Structure(original.lattice, species, final_frac, coords_are_cartesian=False)
    start_virtual_index = kept_indices.index(start_idx)

    return initial, final, start_virtual_index


def write_virtual_endpoint_poscars(material_dir, path_label, initial, final):
    """可选：落盘写出虚拟 b/e POSCAR，便于人工核查。"""
    try:
        from pymatgen.io.vasp import Poscar
    except Exception:
        return None, None

    out_dir = os.path.join(material_dir, VIRTUAL_ENDPOINT_ROOT_NAME, path_label)
    b_dir = os.path.join(out_dir, "b")
    e_dir = os.path.join(out_dir, "e")
    os.makedirs(b_dir, exist_ok=True)
    os.makedirs(e_dir, exist_ok=True)

    b_path = os.path.join(b_dir, POSCAR_NAME)
    e_path = os.path.join(e_dir, POSCAR_NAME)
    Poscar(initial).write_file(b_path)
    Poscar(final).write_file(e_path)
    return b_path, e_path


# =========================
# 旧特征提取逻辑：改为接收内存 initial/final
# =========================
def analyze_endpoint_structures(formula, initial, final):
    """
    对一组已经构造好的初末态结构提取全部原始特征。
    除输入来源从文件改为内存 Structure 外，计算逻辑保持旧脚本一致。
    """
    mig = find_migrating_li(initial, final)
    lattice = initial.lattice

    start_frac = mig["start_frac"]
    end_frac = mig["end_frac"]
    end_frac_image = mig["end_frac_image"]
    migration_vec_cart = mig["vector_cart"]
    mid_frac_unwrapped = 0.5 * (start_frac + end_frac_image)
    mid_frac = np.mod(mid_frac_unwrapped, 1.0)

    c_unit = get_lattice_c_unit(lattice)
    d_LiLi = float(np.linalg.norm(migration_vec_cart))
    out_comp = float(np.dot(migration_vec_cart, c_unit))
    inplane_vec = migration_vec_cart - out_comp * c_unit
    d_inplane = float(np.linalg.norm(inplane_vec))
    d_out_abs = abs(out_comp)
    outplane_ratio = d_out_abs / d_LiLi if d_LiLi > 1e-12 else 0.0
    delta_c_frac = abs(float(end_frac_image[2] - start_frac[2]))

    n_li, n_o, n_cation = count_elements(initial)

    row = zero_row(formula)
    row.update({
        "valid": 1.0,
        "n_atoms": float(len(initial)),
        "n_Li": float(n_li),
        "n_O": float(n_o),
        "n_cations": float(n_cation),
        "d_LiLi": d_LiLi,
        "d_LiLi_inplane": d_inplane,
        "d_LiLi_outplane_abs": d_out_abs,
        "outplane_ratio": outplane_ratio,
        "delta_c_frac": delta_c_frac,
        "mid_frac_a": float(mid_frac[0]),
        "mid_frac_b": float(mid_frac[1]),
        "mid_frac_c": float(mid_frac[2]),
    })

    # 异侧 O-O 瓶颈
    bottleneck = select_opposite_side_oxygen_pair(initial, mid_frac, migration_vec_cart)
    if bottleneck is not None:
        row.update({
            "O_side_valid": bottleneck["O_side_valid"],
            "d_OO_bottleneck_opposite": bottleneck["d_OO"],
            "d_mid_O1": bottleneck["d_mid_O1"],
            "d_mid_O2": bottleneck["d_mid_O2"],
            "d_mid_O_min": bottleneck["d_mid_O_min"],
            "d_mid_O_mean": bottleneck["d_mid_O_mean"],
            "O_bottleneck_asymmetry": bottleneck["asymmetry"],
            "O_path_projection_abs_mean": bottleneck["path_projection_abs_mean"],
            "O_gate_balance": bottleneck["gate_balance"],
        })

    # 中点虚拟 Li-O 环境 + 氧框架
    oxy_mid = distances_from_point(initial, mid_frac, is_o)
    mean4, std4, dist4 = nearest_stats(oxy_mid, 4)
    mean6, std6, dist6 = nearest_stats(oxy_mid, 6)
    row.update({
        "CN_O_mid_2p8": coord_number(oxy_mid, O_CN_CUTOFF_1),
        "CN_O_mid_3p0": coord_number(oxy_mid, O_CN_CUTOFF_2),
        "min_M_O": min_distance(oxy_mid),
        "mean_M_O_4nearest": mean4,
        "std_M_O_4nearest": std4,
        "distortion_MO_4nearest": dist4,
        "mean_M_O_6nearest": mean6,
        "std_M_O_6nearest": std6,
        "distortion_MO_6nearest": dist6,
    })

    framework, _ = local_oxygen_framework_features(initial, mid_frac)
    row.update(framework)

    # 初态 / 末态 Li-O 环境
    oxy_start = distances_from_point(initial, start_frac, is_o)
    oxy_end = distances_from_point(final, end_frac, is_o)
    mean_start4, std_start4, dist_start4 = nearest_stats(oxy_start, 4)
    mean_end4, std_end4, dist_end4 = nearest_stats(oxy_end, 4)
    row.update({
        "CN_O_start_2p8": coord_number(oxy_start, O_CN_CUTOFF_1),
        "CN_O_end_2p8": coord_number(oxy_end, O_CN_CUTOFF_1),
        "min_LiO_start": min_distance(oxy_start),
        "min_LiO_end": min_distance(oxy_end),
        "mean_LiO_start_4nearest": mean_start4,
        "mean_LiO_end_4nearest": mean_end4,
        "std_LiO_start_4nearest": std_start4,
        "std_LiO_end_4nearest": std_end4,
        "distortion_LiO_start": dist_start4,
        "distortion_LiO_end": dist_end4,
        "delta_mean_LiO": mean_end4 - mean_start4,
        "delta_distortion_LiO": dist_end4 - dist_start4,
    })

    # 局域 Li 拥挤程度：排除迁移 Li 本身
    li_mid = distances_from_point(initial, mid_frac, is_li, exclude_indices={mig["index"]})
    num_li_3p0 = sum(1 for x in li_mid if x["distance"] <= 3.0)
    num_li_3p5 = sum(1 for x in li_mid if x["distance"] <= 3.5)
    num_li_4p0 = sum(1 for x in li_mid if x["distance"] <= LI_DENSITY_RADIUS)
    sphere_volume = 4.0 / 3.0 * math.pi * LI_DENSITY_RADIUS ** 3
    row.update({
        "nearest_Li_to_mid": min_distance(li_mid),
        "num_Li_mid_3p0": float(num_li_3p0),
        "num_Li_mid_3p5": float(num_li_3p5),
        "local_Li_density_4p0": float(num_li_4p0 / sphere_volume),
    })

    # 局域非 Li/O 阳离子几何 + 元素物性数值统计
    cation_features, local_cations, all_cations = local_cation_features(initial, mid_frac)
    row.update(cation_features)

    # 保证所有数值都是有限数
    for col in NUMERIC_COLUMNS:
        row[col] = safe_float(row.get(col, 0.0))

    return row, {
        "migrating_virtual_index": int(mig["index"]),
        "start_frac": start_frac,
        "end_frac": end_frac,
        "end_frac_image": end_frac_image,
        "mid_frac": mid_frac,
        "d_LiLi": d_LiLi,
        "d_LiLi_inplane": d_inplane,
    }


def analyze_virtual_path(path_label, original, start_idx, end_idx, material_dir=None):
    """
    对原始结构中的一条 start->end 路径：
        1. 构造虚拟 initial/final；
        2. 可选写出 b/e POSCAR；
        3. 调用旧逻辑提取特征。
    """
    initial, final, start_virtual_index = build_virtual_endpoints_from_original(
        original, start_idx, end_idx
    )

    b_path = None
    e_path = None
    if WRITE_VIRTUAL_ENDPOINTS and material_dir is not None:
        b_path, e_path = write_virtual_endpoint_poscars(material_dir, path_label, initial, final)

    row, info = analyze_endpoint_structures(path_label, initial, final)
    info.update({
        "start_original_index": int(start_idx),
        "end_original_index": int(end_idx),
        "start_virtual_index_expected": int(start_virtual_index),
        "virtual_b_poscar": b_path,
        "virtual_e_poscar": e_path,
    })
    return row, info


def autosize_excel_columns(xlsx_path, sheet_name="features"):
    """用 openpyxl 做简单列宽和冻结首行。"""
    try:
        from openpyxl import load_workbook
        from openpyxl.styles import Font, PatternFill, Alignment
    except Exception:
        return

    wb = load_workbook(xlsx_path)
    ws = wb[sheet_name]
    ws.freeze_panes = "B2"
    ws.auto_filter.ref = ws.dimensions

    header_fill = PatternFill(fill_type="solid", fgColor="D9EAF7")
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for col_cells in ws.columns:
        col_letter = col_cells[0].column_letter
        max_len = 0
        for cell in col_cells:
            value = cell.value
            if value is None:
                continue
            max_len = max(max_len, len(str(value)))
        width = min(max(max_len + 2, 10), 34)
        ws.column_dimensions[col_letter].width = width

    wb.save(xlsx_path)


def process_batch(root_dir):
    root_dir = os.path.abspath(root_dir)
    if not os.path.isdir(root_dir):
        raise ValueError(f"不是有效文件夹：{root_dir}")

    material_items = get_material_dirs(root_dir)
    if not material_items:
        raise ValueError(f"没有找到材料文件夹或原始 {ORIGINAL_STRUCTURE_NAME}：{root_dir}")

    rows = []
    log_lines = []
    log_lines.append(f"Root folder: {root_dir}")
    log_lines.append(f"Number of material folders: {len(material_items)}")
    log_lines.append(f"Original structure name: {ORIGINAL_STRUCTURE_NAME}")
    log_lines.append(f"Li path distance window: [{LI_PATH_MIN_DISTANCE:.3f}, {LI_PATH_MAX_DISTANCE:.3f}] Å")
    log_lines.append(f"Filter in-plane only: {FILTER_INPLANE_ONLY}")
    log_lines.append(
        f"In-plane thresholds: MAX_PATH_OUTPLANE_ABS={MAX_PATH_OUTPLANE_ABS:.3f} Å; "
        f"MAX_PATH_OUTPLANE_RATIO={MAX_PATH_OUTPLANE_RATIO:.3f}; "
        f"MAX_PATH_DELTA_C_FRAC={MAX_PATH_DELTA_C_FRAC:.3f}"
    )
    log_lines.append(f"Merge similar environment paths: {MERGE_SIMILAR_ENVIRONMENT_PATHS}")
    log_lines.append("Environment similarity features: " + ", ".join(ENV_SIMILARITY_FEATURES))
    log_lines.append(f"Use symmetry reduction: {USE_SYMMETRY_REDUCTION}")
    log_lines.append(f"Generate both directions: {GENERATE_BOTH_DIRECTIONS}")
    log_lines.append(f"Write virtual endpoints: {WRITE_VIRTUAL_ENDPOINTS}")
    log_lines.append("Output columns: " + ", ".join(OUTPUT_COLUMNS))
    log_lines.append("")
    log_lines.append("Virtual endpoint construction rule:")
    log_lines.append("  initial = original minus end Li")
    log_lines.append("  final   = initial with the same-index start Li moved to end Li position")
    log_lines.append("  Then the original endpoint feature extraction logic is used.")
    log_lines.append("")

    for k, (formula, material_dir) in enumerate(material_items, 1):
        print(f"[{k}/{len(material_items)}] Processing {formula} ...")
        struct_path = locate_original_structure(material_dir)

        if struct_path is None:
            msg = f"{formula}: MISSING_{ORIGINAL_STRUCTURE_NAME}"
            print("  " + msg)
            log_lines.append(msg)
            continue

        try:
            original = Structure.from_file(struct_path)
            global_feats = extract_global_Li_features(original)
            paths = enumerate_inequivalent_odh_paths(original)
        except Exception as exc:
            msg = f"{formula}: ERROR_WHILE_READING_OR_ENUMERATING_PATHS; {repr(exc)}"
            print("  " + msg)
            log_lines.append(msg)
            log_lines.append(traceback.format_exc().rstrip())
            continue

        log_lines.append(f"{formula}: structure={struct_path}")
        log_lines.append(f"{formula}: n_atoms={len(original)}, n_Li={len(li_site_indices(original))}, n_paths={len(paths)}")
        log_lines.append(
            f"{formula}: a_times_b={global_feats['a_times_b']:.6f}; "
            f"Li_to_transition_metal_ratio={global_feats['Li_to_transition_metal_ratio']:.6f}"
        )

        if len(paths) == 0:
            log_lines.append(f"{formula}: NO_INPLANE_PATHS_IN_DISTANCE_WINDOW")
            continue

        material_path_records = []

        for p_idx, path in enumerate(paths, 1):
            raw_path_label = f"{formula}_raw_path{p_idx}"
            start_idx = int(path["start_idx"])
            end_idx = int(path["end_idx"])
            dist = float(path["distance"])
            image_tuple = tuple(int(x) for x in path["image"])

            try:
                row, info = analyze_virtual_path(
                    raw_path_label,
                    original,
                    start_idx,
                    end_idx,
                    material_dir=material_dir,
                )
            except Exception as exc:
                log_lines.append(f"{raw_path_label}: ERROR; {repr(exc)}")
                log_lines.append(traceback.format_exc().rstrip())
                continue

            row.update(global_feats)

            material_path_records.append({
                "label": raw_path_label,
                "row": row,
                "info": info,
                "start_idx": start_idx,
                "end_idx": end_idx,
                "distance": dist,
                "image_tuple": image_tuple,
            })

            log_lines.append(
                f"{raw_path_label}: OK; "
                f"start_original_index={start_idx}; end_original_index={end_idx}; "
                f"raw_LiLi_distance={dist:.6f} Å; raw_end_image={image_tuple}; "
                f"migrating_virtual_index={info['migrating_virtual_index']}; "
                f"d_LiLi_inplane={info['d_LiLi_inplane']:.6f} Å; "
                f"d_OO_bottleneck_opposite={row['d_OO_bottleneck_opposite']:.6f} Å"
            )
            if WRITE_VIRTUAL_ENDPOINTS:
                log_lines.append(f"  virtual_b_POSCAR={info.get('virtual_b_poscar')}")
                log_lines.append(f"  virtual_e_POSCAR={info.get('virtual_e_poscar')}")

        if len(material_path_records) == 0:
            log_lines.append(f"{formula}: NO_VALID_INPLANE_PATH_AFTER_FEATURE_EXTRACTION")
            log_lines.append("")
            continue

        groups = merge_similar_environment_paths(material_path_records)
        log_lines.append(
            f"{formula}: raw_inplane_paths={len(material_path_records)}, "
            f"merged_environment_path_groups={len(groups)}"
        )

        for g_idx, group in enumerate(groups, 1):
            out_row = build_group_output_row(formula, g_idx, group, global_feats)
            rows.append({col: out_row.get(col, 0.0) for col in OUTPUT_COLUMNS})

            members = group["members"]
            member_labels = ",".join(member["label"] for member in members)
            rep = group["representative"]
            log_lines.append(
                f"{formula}_path{g_idx}: MERGED_GROUP; "
                f"group_size={len(members)}; representative={rep['label']}; "
                f"members={member_labels}"
            )

        log_lines.append("")

    df = pd.DataFrame(rows, columns=OUTPUT_COLUMNS)

    if df.empty:
        # 仍然写出空表头，防止批量运行后没有可检查文件。
        df = pd.DataFrame(columns=OUTPUT_COLUMNS)

    for col in OUTPUT_NUMERIC_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    xlsx_path = os.path.join(root_dir, f"{EXCEL_PREFIX}_{timestamp}.xlsx")

    with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="features")

    autosize_excel_columns(xlsx_path, sheet_name="features")

    batch_log_path = os.path.join(root_dir, f"{EXCEL_PREFIX}_{timestamp}{BATCH_LOG_SUFFIX}")
    with open(batch_log_path, "w", encoding="utf-8") as f:
        f.write("\n".join(log_lines))

    print("\nDone!")
    print(f"Excel summary: {xlsx_path}")
    print(f"Batch log    : {batch_log_path}")

    return xlsx_path, batch_log_path


def choose_folder_gui_or_cli():
    """优先用命令行参数；没有参数时弹出文件夹选择框；再失败则用手动输入。"""
    if len(sys.argv) >= 2 and sys.argv[1].strip():
        return sys.argv[1].strip().strip('"')

    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        folder = filedialog.askdirectory(title="选择包含多个原始 CONTCAR 的总文件夹")
        root.destroy()
        if folder:
            return folder
    except Exception:
        pass

    return input("请输入总文件夹路径：").strip().strip('"')


def main():
    print("Batch original CONTCAR in-plane ODH path feature extractor - 2 global features + 6 grouped path features")
    print("Folder structure: root/formula/CONTCAR")
    print("For each in-plane Li-Li path, virtual b/e endpoints are constructed in memory.")
    print("Only one Excel sheet and one batch log txt will be generated. The two global features are repeated for each grouped in-plane path row.\n")

    root_dir = choose_folder_gui_or_cli()
    if not root_dir:
        print("No folder selected. Exit.")
        return

    try:
        process_batch(root_dir)
    except Exception as exc:
        print("\nERROR:")
        print(repr(exc))
        traceback.print_exc()

    if sys.stdin.isatty():
        try:
            input("\nPress Enter to exit...")
        except Exception:
            pass


if __name__ == "__main__":
    main()
