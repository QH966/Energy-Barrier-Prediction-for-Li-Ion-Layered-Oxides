#!/usr/bin/env python3
"""递归发现 CONTCAR，并调用未经修改的原始特征提取器和模型。"""

from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import sys
import tempfile
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor

import feature_extractor as extractor

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model" / "catboost_best_model.cbm"
METADATA_PATH = BASE_DIR / "model" / "model_metadata.json"
FEATURE_MAP = {
    "a_times_b": "A_ab",
    "Li_to_transition_metal_ratio": "R_Li/TM",
    "d_OO_bottleneck_opposite": "d_OO",
    "O_bottleneck_asymmetry": "∆d_O",
    "wmean_cation_mendeleev_3p5": "M_cat",
    "distortion_LiO_end": "σ_LiO,end",
    "mean_M_O_6nearest": "d̄_MO,6",
    "d_LiLi_inplane": "d_LiLi",
}
SKIP_DIRS = {"__pycache__", "venv", "env", "node_modules", "catboost_info"}


def discover_structures(input_path: Path) -> list[tuple[str, Path]]:
    input_path = input_path.expanduser().resolve()
    if input_path.is_file():
        if input_path.name != "CONTCAR":
            raise ValueError("The input file must be named CONTCAR (case-sensitive).")
        return [(input_path.parent.name, input_path)]
    if not input_path.is_dir():
        raise FileNotFoundError(f"Input directory or file does not exist: {input_path}")

    def on_error(error):
        raise error

    found = []
    for directory, dirs, files in os.walk(input_path, followlinks=False, onerror=on_error):
        dirs[:] = sorted(
            name for name in dirs
            if not name.startswith(".") and name not in SKIP_DIRS
            and not (Path(directory) / name).is_symlink()
        )
        if "CONTCAR" in files:
            source = Path(directory) / "CONTCAR"
            if not source.is_symlink():
                name = source.parent.relative_to(input_path).as_posix()
                found.append((name, source))
    if not found:
        raise FileNotFoundError("No files named CONTCAR were found recursively.")
    return sorted(found, key=lambda item: item[0])


def build_model_table(raw_table: pd.DataFrame, feature_columns: list[str]) -> pd.DataFrame:
    missing = [column for column in ["formula", *FEATURE_MAP] if column not in raw_table]
    if missing:
        raise ValueError("Missing extracted columns: " + ", ".join(missing))
    labels = raw_table["formula"].astype(str).str.extract(r"^(s\d+)_path(\d+)$")
    if labels.isna().any().any():
        raise ValueError("Invalid path labels returned by the feature extractor.")
    table = pd.DataFrame({"structure_id": labels[0], "path_id": labels[1].astype(int)})
    for source, target in FEATURE_MAP.items():
        table[target] = pd.to_numeric(raw_table[source], errors="coerce")
    if not np.isfinite(table[feature_columns].to_numpy(dtype=float)).all():
        raise ValueError("Extracted model features contain non-finite values.")
    return table


def save_results(results: pd.DataFrame, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.suffix.lower() == ".csv":
        exported = results.copy()
        for column in ("structure", "path", "source_file"):
            exported[column] = exported[column].map(
                lambda value: "'" + value if value.startswith(("=", "+", "-", "@", "\t", "\r", "\n")) else value
            )
        with output.open("x", encoding="utf-8-sig", newline="") as stream:
            exported.to_csv(stream, index=False)
    else:
        with output.open("xb") as stream:
            with pd.ExcelWriter(stream, engine="openpyxl") as writer:
                results.to_excel(writer, sheet_name="predictions", index=False)
                results[results["rank_in_structure"] == 1].to_excel(
                    writer, sheet_name="lowest_barriers", index=False
                )
                for sheet in writer.sheets.values():
                    for row in sheet.iter_rows(min_row=2):
                        for index in (0, 1, 5):
                            row[index].data_type = "s"


def run(input_path: Path, output_path: Path | None, max_distance: float = 4.0) -> Path:
    if not math.isfinite(max_distance) or max_distance <= extractor.LI_PATH_MIN_DISTANCE:
        raise ValueError(f"--max-distance must be finite and > {extractor.LI_PATH_MIN_DISTANCE}.")
    if output_path is None:
        output_path = Path.cwd() / f"predictions_{datetime.now():%Y%m%d_%H%M%S_%f}.csv"
    output = output_path.expanduser().resolve()
    if output.suffix.lower() not in {".csv", ".xlsx"}:
        raise ValueError("Output must use the .csv or .xlsx extension.")
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite an existing file: {output}")

    structures = discover_structures(input_path)
    metadata = json.loads(METADATA_PATH.read_text(encoding="utf-8"))
    feature_columns = metadata["feature_columns"]
    if feature_columns != list(FEATURE_MAP.values()):
        raise ValueError("Metadata feature names/order do not match the original feature mapping.")
    model = CatBoostRegressor()
    model.load_model(str(MODEL_PATH))
    if list(model.feature_names_) != feature_columns:
        raise ValueError("Model feature names/order do not match model_metadata.json.")
    extractor.LI_PATH_MAX_DISTANCE = max_distance
    print(f"Found {len(structures)} CONTCAR file(s).")
    source_map = {}
    with tempfile.TemporaryDirectory(prefix="contcar_predict_") as temporary_dir:
        workspace = Path(temporary_dir)
        for index, (name, source) in enumerate(structures, 1):
            structure_id = f"s{index:06d}"
            target = workspace / structure_id
            target.mkdir()
            shutil.copy2(source, target / "CONTCAR")
            source_map[structure_id] = (name, source)
            print(f"{structure_id}: {source}")
        raw_path, log_path = extractor.process_batch(str(workspace))
        raw_table = pd.read_excel(raw_path, sheet_name="features")
        log = Path(log_path).read_text(encoding="utf-8")

    errors = [line for line in log.splitlines() if "ERROR" in line or "NO_INPLANE_PATH" in line
              or "NO_VALID_INPLANE_PATH" in line]
    if errors:
        print("\n".join(errors), file=sys.stderr)
        raise RuntimeError("Extraction failed or no paths were found for an input; no predictions saved.")
    if raw_table.empty:
        raise RuntimeError("No valid in-plane Li migration paths; no predictions saved.")
    table = build_model_table(raw_table, feature_columns)
    if set(table["structure_id"]) != set(source_map):
        raise RuntimeError("Some inputs have no extracted paths; no predictions saved.")
    table["predicted_barrier_eV"] = model.predict(table[feature_columns])
    if not np.isfinite(table["predicted_barrier_eV"]).all():
        raise RuntimeError("Model returned non-finite predictions.")
    table["structure"] = table["structure_id"].map(lambda key: source_map[key][0])
    table["source_file"] = table["structure_id"].map(lambda key: str(source_map[key][1]))
    table["path"] = table["structure"] + "_path" + table["path_id"].astype(str)
    table = table.sort_values(
        ["structure", "predicted_barrier_eV", "path_id"], kind="stable"
    ).reset_index(drop=True)
    table["rank_in_structure"] = table.groupby("structure_id").cumcount() + 1
    table = table[["structure", "path", "path_id", "rank_in_structure",
                   "predicted_barrier_eV", "source_file", *feature_columns]]
    save_results(table, output)
    print(f"Predicted {len(table)} path group(s) across {len(structures)} structure(s).")
    print(f"Saved: {output}")
    return output


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Recursively find CONTCAR files, extract original features and predict Li migration barriers."
    )
    parser.add_argument("input", type=Path, help="A CONTCAR file or a directory to scan recursively.")
    parser.add_argument("-o", "--output", type=Path, help="New output CSV or XLSX file (never overwritten).")
    parser.add_argument("--max-distance", type=float, default=4.0,
                        help="Maximum candidate Li-Li distance in angstroms (default: 4.0).")
    args = parser.parse_args()
    try:
        run(args.input, args.output, args.max_distance)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
