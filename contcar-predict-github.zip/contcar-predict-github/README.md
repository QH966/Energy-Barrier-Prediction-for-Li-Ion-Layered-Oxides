# CONTCAR Batch Barrier Predictor

A small, local command-line project that recursively finds `CONTCAR` files, runs the original eight-feature extraction workflow, and predicts in-plane lithium migration barriers with the supplied trained CatBoost model. No notebook, server, account, GPU, or retraining is required.

```text
CONTCAR files (recursive discovery)
  -> original in-plane Li-Li path enumeration
  -> symmetry reduction and local-environment grouping
  -> original eight descriptors
  -> original model feature names and order
  -> CatBoost prediction
  -> ranked CSV or Excel results
```

This is a complete prediction pipeline, not a structure-information scanner. Predictions are screening estimates, not NEB calculations or experimental measurements.

## Files

```text
contcar-predict-github/
├── predict.py
├── feature_extractor.py
├── requirements.txt
├── README.md
├── .gitignore
├── model/
│   ├── catboost_best_model.cbm
│   └── model_metadata.json
└── examples/
    └── sample/
        └── CONTCAR
```

`feature_extractor.py` is a byte-for-byte copy of the original scientific script. The model is also unchanged. The metadata preserves the original model fields, order, parameters, and recorded metrics; only the private local training-data path was removed. The original extractor retains its original comments and diagnostics, including some Chinese messages. Run **`predict.py`**, not the extractor's standalone legacy entry point.

## Installation

Python 3.12 is recommended for reproducing the validated environment. Other Python versions and operating systems have not been tested for this package.

Run these commands from the extracted project directory.

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe predict.py examples -o results.csv
```

### Linux / macOS

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python predict.py examples -o results.csv
```

Use your virtual environment's interpreter for the remaining examples (`python` below assumes it is already activated).

## Usage

Recursively process a directory:

```bash
python predict.py "path/to/structures" -o results.csv
```

Export an Excel workbook:

```bash
python predict.py "path/to/structures" -o results.xlsx
```

Process a single file:

```bash
python predict.py "path/to/material/CONTCAR" -o single.csv
```

Use the included example:

```bash
python predict.py examples -o example_predictions.csv
```

Show command-line help:

```bash
python predict.py --help
```

If `-o` is omitted, a new `predictions_YYYYMMDD_HHMMSS_microseconds.csv` is created in the current working directory. Model and metadata paths are resolved relative to `predict.py`, not the working directory. Existing output files are never overwritten: choose a different output name for each run.

The only optional scientific parameter exposed by the wrapper is:

```bash
python predict.py "path/to/structures" --max-distance 4.0 -o results.csv
```

The default maximum Li-Li candidate distance is 4.0 angstroms. Change it only with physical justification and revalidate the results; the model is not retrained when this option changes.

## Input discovery

Files must be named exactly `CONTCAR` (case-sensitive). The wrapper deliberately does not auto-detect POSCAR, CIF, compressed files, or arbitrary extensions.

```text
structures/
├── CONTCAR
├── family_A/
│   └── relaxed/
│       └── CONTCAR
└── family_B/
    └── relaxed/
        └── CONTCAR
```

All three files are processed, including both the root file and nested files. Structure identifiers are relative directory paths (`.`, `family_A/relaxed`, `family_B/relaxed`), so repeated leaf directory names do not collide. For a single-file input, the parent directory name is used.

Hidden subdirectories (names starting with `.`), `__pycache__`, `venv`, `env`, `node_modules`, and `catboost_info` are skipped. Child symbolic links are not followed. Supply a dedicated structures directory rather than a whole disk or a directory containing unrelated copies of the same data. Files with identical contents in different directories are treated as separate inputs.

The wrapper copies inputs into an automatically cleaned temporary directory before invoking the original extractor. It does not modify input structures or write intermediate files beside them. Intermediate feature spreadsheets and extraction logs are temporary and are not retained.

## Outputs

CSV contains all predicted path groups in UTF-8 with BOM. Excel contains `predictions` (all groups) and `lowest_barriers` (the first-ranked group for each structure).

| Column | Meaning |
| --- | --- |
| `structure` | Relative directory identifier, or parent name for a single-file input |
| `path` | Structure identifier followed by `_pathN` |
| `path_id` | Original grouped path number within the structure |
| `rank_in_structure` | 1-based ascending predicted-barrier order; ties use `path_id` |
| `predicted_barrier_eV` | Predicted migration barrier, labeled eV following the original workflow |
| `source_file` | Absolute path of the original CONTCAR |
| Eight feature columns below | Actual model inputs, using the original Unicode names |

The model feature names are **not** replaced with ASCII aliases. The wrapper checks that the metadata, feature mapping, and the loaded model agree exactly in both names and order.

| Model column | Original extraction column | Meaning / unit |
| --- | --- | --- |
| `A_ab` | `a_times_b` | Lattice parameter product a × b, angstrom² (not a × b × sin(gamma)) |
| `R_Li/TM` | `Li_to_transition_metal_ratio` | Li / transition-metal count ratio |
| `d_OO` | `d_OO_bottleneck_opposite` | Oxygen bottleneck distance, angstrom |
| `∆d_O` | `O_bottleneck_asymmetry` | Absolute difference of midpoint-to-gate-oxygen distances, angstrom |
| `M_cat` | `wmean_cation_mendeleev_3p5` | Inverse-distance-weighted local cation Mendeleev number |
| `σ_LiO,end` | `distortion_LiO_end` | Endpoint Li-O standard deviation / mean for up to four nearest O sites |
| `d̄_MO,6` | `mean_M_O_6nearest` | Mean midpoint-to-O distance for up to six nearest O sites, angstrom |
| `d_LiLi` | `d_LiLi_inplane` | In-plane Li-Li path length, angstrom |

Output files contain local absolute input paths. Remove that column before sharing results if those paths are private. Text identifiers are written as text in XLSX; CSV text starting with spreadsheet formula-trigger characters is prefixed with an apostrophe for safer spreadsheet viewing.

## Preserved scientific workflow

The original script enumerates pairs of Li sites under periodic boundary conditions, with a default distance window of 0.30–4.00 angstroms. It retains only paths satisfying all three in-plane criteria: absolute c-axis projection <= 0.80 angstroms, projection/distance <= 0.25, and fractional c-coordinate displacement <= 0.08. Space-group symmetry reduction is enabled (`symprec=0.001`, angle tolerance 5 degrees), and both directions are not separately generated by default.

For each path, the virtual initial state removes the endpoint Li; the virtual final state moves the same-index starting Li to the endpoint. The original endpoint-based descriptor routines are then used. Similar paths are grouped using the original five local-feature tolerances, and grouped path features are averaged. No geometry, feature formulas, grouping thresholds, missing-value fallback, or fitted model parameters were rewritten.

## Errors and limitations

- Exit status is `0` on success and nonzero on failure (`1` for runtime validation errors; argparse may return `2` for invalid command syntax).
- A malformed structure, extraction error, or a structure without valid paths causes the batch to fail **without saving a partial prediction table**. Diagnostics include temporary structure IDs; the console maps each ID to its original file.
- Missing/empty input, unsupported output extensions, invalid distances, and existing output files are rejected.
- At least two Li sites and a suitable layered lithium-oxide environment are expected. Cross-layer diffusion, non-Li mechanisms, strong disorder, and out-of-distribution chemistries are not validated.
- The original extractor can replace missing/non-finite descriptors with zero, fall back to a nearby oxygen pair when an opposite-side pair is unavailable, or fall back to identity symmetry operations. Those original behaviors are preserved and are **not** equivalent to a scientific quality guarantee. Finite features alone do not establish physical validity.
- The model was trained on 125 samples (100 training / 25 test). Metadata records test R² = 0.8926, RMSE = 0.0542, MAE = 0.0444. These are historical recorded metrics, not newly reproduced accuracy measurements. The test set was also used for early stopping/model selection; this is not a fully independent external assessment.
- The eV label follows the source workflow; the original metadata does not independently specify a target-unit field.
- Important candidates require independent validation, such as NEB calculations or experiments. No external accuracy study, throughput benchmark, or cross-platform test is claimed.
- Do not load model files from untrusted sources. Confirm redistribution rights for the code, example structure, and trained model before publishing; this packaging step does not grant a new license.

## Validation

Validated locally on Windows with Python 3.12.10, CatBoost 1.2.8, pymatgen 2026.10.24, NumPy 2.5.4, pandas 2.3.3, and openpyxl 3.1.5. Dependency consistency checks passed.

Completed checks:

- Full CLI prediction on all five original example structures in nested folders with repeated leaf directory names: 115, 127, 123, 115, and 120 path groups (600 total).
- All eight extracted features and all predictions compared against the original extractor, original conversion script, and original model; agreement within `1e-12`, maximum prediction difference `1.11e-16` after CSV serialization.
- Single-file input, CSV output, XLSX output and its lowest-barrier sheet, ascending ranking, and input-source mapping.
- Root and nested CONTCAR discovery together; exclusion of hidden/environment/cache directories.
- Rejection of missing/empty input, invalid output extension, invalid/non-finite maximum distance, and existing outputs.
- Malformed mixed batch and no-path structure return failure without a partial prediction table.
- Syntax checks and spreadsheet formula-injection guards for text identifiers.
- SHA-256 comparison confirms the packaged model and extractor are identical to the originals; protected original project files were unchanged by testing.

These are functional and numerical-regression checks, not a new assessment of prediction accuracy. Dependencies are version-bounded rather than a complete transitive lock file; a future fresh installation may resolve different versions.
